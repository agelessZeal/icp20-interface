"use strict";
exports.id = 1208;
exports.ids = [1208];
exports.modules = {

/***/ 1208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ getCurrencyLogoUrls),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5914);
/* harmony import */ var _state_lists_wrappedTokenInfo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2045);
/* harmony import */ var _hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3278);
/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5579);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7735);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
const _excluded = ["currency", "size", "style", "className"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const BLOCKCHAIN = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'ethereum',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: 'binanace',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: 'celo',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: 'fantom',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: 'harmony',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: 'polygon',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: 'xdai' // [ChainId.OKEX]: 'okex',

};

function getCurrencySymbol(currency) {
  if (currency.symbol === 'WBTC') {
    return 'btc';
  }

  if (currency.symbol === 'WETH') {
    return 'eth';
  }

  return currency.symbol.toLowerCase();
}

function getCurrencyLogoUrls(currency) {
  const urls = [];
  urls.push(`https://raw.githubusercontent.com/sushiswap/icons/master/token/${getCurrencySymbol(currency)}.jpg`);

  if (currency.chainId in BLOCKCHAIN) {
    urls.push(`https://raw.githubusercontent.com/sushiswap/assets/master/blockchains/${BLOCKCHAIN[currency.chainId]}/assets/${currency.address}/logo.png`);
    urls.push(`https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/${BLOCKCHAIN[currency.chainId]}/assets/${currency.address}/logo.png`);
  }

  return urls;
}
const AvalancheLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/avax.jpg';
const BinanceCoinLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/bnb.jpg';
const EthereumLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/eth.jpg';
const FantomLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/ftm.jpg';
const HarmonyLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/one.jpg';
const HecoLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/heco.jpg';
const MaticLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/polygon.jpg';
const MoonbeamLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/eth.jpg';
const OKExLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/okt.jpg';
const xDaiLogo = 'https://raw.githubusercontent.com/sushiswap/assets/master/blockchains/xdai/assets/0xe91D153E0b41518A2Ce8Dd3D7944Fa863463a97d/logo.png';
const CeloLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/celo.jpg';
const PalmLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/palm.jpg';
const MovrLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/movr.jpg';
const LOGO = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: EthereumLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: FantomLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: FantomLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: MaticLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: MaticLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: xDaiLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: BinanceCoinLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: BinanceCoinLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: MoonbeamLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: AvalancheLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: AvalancheLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: HecoLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: HecoLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: HarmonyLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: HarmonyLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: OKExLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: OKExLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: EthereumLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: EthereumLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: CeloLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM]: PalmLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM_TESTNET]: PalmLogo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONRIVER]: MovrLogo
};
const unknown = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/unknown.png';

const CurrencyLogo = _ref => {
  let {
    currency,
    size = '24px',
    style,
    className = ''
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const uriLocations = (0,_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(currency instanceof _state_lists_wrappedTokenInfo__WEBPACK_IMPORTED_MODULE_3__/* .WrappedTokenInfo */ .D ? currency.logoURI || currency.tokenInfo.logoURI : undefined);
  const srcs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => {
    if (!currency) {
      return [unknown];
    }

    if (currency.isNative || currency.equals(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.WNATIVE[currency.chainId])) {
      return [LOGO[currency.chainId], unknown];
    }

    if (currency.isToken) {
      const defaultUrls = [...getCurrencyLogoUrls(currency)];

      if (currency instanceof _state_lists_wrappedTokenInfo__WEBPACK_IMPORTED_MODULE_3__/* .WrappedTokenInfo */ .D) {
        return [...uriLocations, ...defaultUrls, unknown];
      }

      return defaultUrls;
    }
  }, [currency, uriLocations]);

  if (currency && currency.isToken) {
    if (currency instanceof _state_lists_wrappedTokenInfo__WEBPACK_IMPORTED_MODULE_3__/* .WrappedTokenInfo */ .D && currency.chainId === _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC) {
      if (currency.tokenInfo.address.toLowerCase() === '0x1b43b97094aa3c6cc678edb9e28ac67daaa7cc64') {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Image__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, _objectSpread({
          src: "/images/tokens/licp.png",
          width: size,
          height: size,
          alt: currency === null || currency === void 0 ? void 0 : currency.symbol,
          className: (0,_functions__WEBPACK_IMPORTED_MODULE_6__/* .classNames */ .AK)('rounded-full', className)
        }, rest));
      }

      if (currency.tokenInfo.address.toLowerCase() === '0xe7946921c619f5d9e8f28e3a5b4d218e9520dd11') {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Image__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, _objectSpread({
          src: "/images/tokens/sticp.png",
          width: size,
          height: size,
          alt: currency === null || currency === void 0 ? void 0 : currency.symbol,
          className: (0,_functions__WEBPACK_IMPORTED_MODULE_6__/* .classNames */ .AK)('rounded-full', className)
        }, rest));
      }

      if (currency.tokenInfo.address.toLowerCase() === '0xd63568e4bcb3d32c928e243e2bdb9e272d748a06') {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Image__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, _objectSpread({
          src: "/images/tokens/wicp.png",
          width: size,
          height: size,
          alt: currency === null || currency === void 0 ? void 0 : currency.symbol,
          className: (0,_functions__WEBPACK_IMPORTED_MODULE_6__/* .classNames */ .AK)('rounded-full', className)
        }, rest));
      }
    }
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, _objectSpread({
    srcs: srcs,
    width: size,
    height: size,
    alt: currency === null || currency === void 0 ? void 0 : currency.symbol,
    className: className
  }, rest));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrencyLogo);

/***/ }),

/***/ 5914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5579);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var _functions_cloudinary__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3801);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
const _excluded = ["srcs", "width", "height", "style", "alt", "className"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const BAD_SRCS = {};

/**
 * Renders an image by sequentially trying a list of URIs, and then eventually a fallback triangle alert
 */
const Logo = _ref => {
  let {
    srcs,
    width,
    height,
    style,
    alt = '',
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    1: refresh
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const src = srcs.find(src => !BAD_SRCS[src]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: "rounded-full",
    style: _objectSpread({
      width,
      height
    }, style),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_Image__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, _objectSpread({
      src: src || 'https://raw.githubusercontent.com/sushiswap/icons/master/token/unknown.png',
      loader: _functions_cloudinary__WEBPACK_IMPORTED_MODULE_4__/* .cloudinaryLoader */ .H,
      onError: () => {
        if (src) BAD_SRCS[src] = true;
        refresh(i => i + 1);
      },
      width: width,
      height: height,
      alt: alt,
      layout: "fixed",
      className: (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)('rounded-full', className)
    }, rest))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);

/***/ }),

/***/ 3801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ cloudinaryLoader)
/* harmony export */ });
const normalize = src => {
  return src[0] === '/' ? src.slice(1) : src;
};

const cloudinaryLoader = ({
  src,
  width,
  style
}) => {
  return `${normalize(src)}`;
};

/***/ }),

/***/ 3278:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ useHttpLocations)
});

// EXTERNAL MODULE: ./src/functions/convert/index.ts + 3 modules
var convert = __webpack_require__(7025);
// EXTERNAL MODULE: ./src/functions/ens.ts
var functions_ens = __webpack_require__(1302);
// EXTERNAL MODULE: ./src/hooks/useContract.ts + 31 modules
var useContract = __webpack_require__(6435);
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: external "@ethersproject/hash"
var hash_ = __webpack_require__(1101);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/state/multicall/hooks.ts
var hooks = __webpack_require__(879);
;// CONCATENATED MODULE: ./src/hooks/useENSContentHash.ts





/**
 * Does a lookup for an ENS name to find its contenthash.
 */

function useENSContentHash(ensName) {
  var _resolverAddressResul, _contenthash$result$, _contenthash$result;

  const ensNodeArgument = (0,external_react_.useMemo)(() => {
    if (!ensName) return [undefined];

    try {
      return ensName ? [(0,hash_.namehash)(ensName)] : [undefined];
    } catch (error) {
      return [undefined];
    }
  }, [ensName]);
  const registrarContract = (0,useContract/* useENSRegistrarContract */.zb)(false);
  const resolverAddressResult = (0,hooks/* useSingleCallResult */.Wk)(registrarContract, 'resolver', ensNodeArgument);
  const resolverAddress = (_resolverAddressResul = resolverAddressResult.result) === null || _resolverAddressResul === void 0 ? void 0 : _resolverAddressResul[0];
  const resolverContract = (0,useContract/* useENSResolverContract */.uU)(resolverAddress && (0,functions/* isZero */.Fr)(resolverAddress) ? undefined : resolverAddress, false);
  const contenthash = (0,hooks/* useSingleCallResult */.Wk)(resolverContract, 'contenthash', ensNodeArgument);
  return {
    contenthash: (_contenthash$result$ = (_contenthash$result = contenthash.result) === null || _contenthash$result === void 0 ? void 0 : _contenthash$result[0]) !== null && _contenthash$result$ !== void 0 ? _contenthash$result$ : null,
    loading: resolverAddressResult.loading || contenthash.loading
  };
}
;// CONCATENATED MODULE: ./src/hooks/useHttpLocations.ts




function useHttpLocations(uri) {
  const ens = (0,external_react_.useMemo)(() => uri ? (0,functions_ens/* parseENSAddress */.y)(uri) : undefined, [uri]);
  const resolvedContentHash = useENSContentHash(ens === null || ens === void 0 ? void 0 : ens.ensName);
  return (0,external_react_.useMemo)(() => {
    if (ens) {
      return resolvedContentHash.contenthash ? (0,convert/* uriToHttp */.ie)((0,convert/* contenthashToUri */.il)(resolvedContentHash.contenthash)) : [];
    } else {
      return uri ? (0,convert/* uriToHttp */.ie)(uri) : [];
    }
  }, [ens, resolvedContentHash.contenthash, uri]);
}

/***/ })

};
;
//# sourceMappingURL=1208.js.map