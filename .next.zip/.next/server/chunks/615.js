"use strict";
exports.id = 615;
exports.ids = [615];
exports.modules = {

/***/ 615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "pM": () => (/* binding */ ConfirmationModalContent),
  "ht": () => (/* binding */ TransactionErrorContent),
  "ZP": () => (/* binding */ modals_TransactionConfirmationModal)
});

// UNUSED EXPORTS: ConfirmationPendingContent, TransactionSubmittedContent

// EXTERNAL MODULE: external "react-feather"
var external_react_feather_ = __webpack_require__(9337);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./src/components/CloseIcon/index.tsx
var CloseIcon = __webpack_require__(5298);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: ./src/components/Image/index.tsx
var Image = __webpack_require__(5579);
// EXTERNAL MODULE: external "lottie-react"
var external_lottie_react_ = __webpack_require__(2409);
var external_lottie_react_default = /*#__PURE__*/__webpack_require__.n(external_lottie_react_);
// EXTERNAL MODULE: ./src/components/Modal/index.tsx
var Modal = __webpack_require__(1441);
// EXTERNAL MODULE: ./src/components/ModalHeader/index.tsx
var ModalHeader = __webpack_require__(7144);
// EXTERNAL MODULE: ./src/components/Row/index.tsx
var Row = __webpack_require__(7745);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
;// CONCATENATED MODULE: ./src/animation/loading-rolling-circle.json
const loading_rolling_circle_namespaceObject = JSON.parse('{"v":"5.6.10","fr":24,"ip":0,"op":72,"w":500,"h":500,"nm":"339-loader-10","ddd":0,"assets":[{"id":"comp_0","layers":[]}],"layers":[{"ddd":0,"ind":1,"ty":0,"nm":"Watermark","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[250,250,0],"ix":2},"a":{"a":0,"k":[250,250,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"tm":{"a":0,"k":0.292,"ix":2},"w":500,"h":500,"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":3,"nm":"Color  & Stroke Change","sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ef":[{"ty":5,"nm":"Primary","np":3,"mn":"ADBE Color Control","ix":1,"en":1,"ef":[{"ty":2,"nm":"Color","mn":"ADBE Color Control-0001","ix":1,"v":{"a":0,"k":[0.886,0.886,0.886],"ix":1}}]},{"ty":5,"nm":"Secondary","np":3,"mn":"ADBE Color Control","ix":2,"en":1,"ef":[{"ty":2,"nm":"Color","mn":"ADBE Color Control-0001","ix":1,"v":{"a":0,"k":[0,0.714,0.945],"ix":1}}]},{"ty":5,"nm":"Stroke","np":3,"mn":"ADBE Slider Control","ix":3,"en":1,"ef":[{"ty":0,"nm":"Slider","mn":"ADBE Slider Control-0001","ix":1,"v":{"a":0,"k":112,"ix":1}}]},{"ty":5,"nm":"Scale","np":3,"mn":"ADBE Slider Control","ix":4,"en":1,"ef":[{"ty":0,"nm":"Slider","mn":"ADBE Slider Control-0001","ix":1,"v":{"a":0,"k":100,"ix":1}}]},{"ty":5,"nm":"Axis","np":3,"mn":"ADBE Point Control","ix":5,"en":1,"ef":[{"ty":3,"nm":"Point","mn":"ADBE Point Control-0001","ix":1,"v":{"a":0,"k":[250,250],"ix":1}}]}],"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":3,"nm":"NULL 2","sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[250,250,0],"ix":2,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Axis\')(\'Point\');"},"a":{"a":0,"k":[60,60,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6,"x":"var $bm_rt;\\nvar temp;\\ntemp = thisComp.layer(\'Color  & Stroke Change\').effect(\'Scale\')(\'Slider\');\\n$bm_rt = [\\n    temp,\\n    temp\\n];"}},"ao":0,"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":4,"ty":4,"nm":"Shape Layer 3","parent":5,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.562],"y":[0.589]},"o":{"x":[0.195],"y":[0.225]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.8]},"o":{"x":[0.31],"y":[0.311]},"t":18,"s":[185.773]},{"i":{"x":[0.69],"y":[0.686]},"o":{"x":[0.167],"y":[0.198]},"t":36,"s":[359.73]},{"i":{"x":[0.805],"y":[0.774]},"o":{"x":[0.438],"y":[0.415]},"t":54,"s":[533.78]},{"t":72,"s":[720]}],"ix":10},"p":{"a":0,"k":[0,23.125,0],"ix":2},"a":{"a":0,"k":[0,23.125,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"d":1,"ty":"el","s":{"a":0,"k":[20,20],"ix":2},"p":{"a":0,"k":[0,0],"ix":3},"nm":"Ellipse Path 1","mn":"ADBE Vector Shape - Ellipse","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Primary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":1,"lj":1,"ml":4,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,33.125],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":-1,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Ellipse 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":5,"ty":4,"nm":"Shape Layer 2","parent":6,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.21],"y":[0.543]},"o":{"x":[0.167],"y":[0.397]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.602]},"o":{"x":[0.79],"y":[0.46]},"t":18,"s":[90]},{"i":{"x":[0.21],"y":[0.539]},"o":{"x":[0.167],"y":[0.398]},"t":36,"s":[180]},{"i":{"x":[0.833],"y":[0.601]},"o":{"x":[0.79],"y":[0.462]},"t":54,"s":[270]},{"t":72,"s":[360]}],"ix":10},"p":{"a":0,"k":[0,0,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"d":1,"ty":"el","s":{"a":0,"k":[46,46],"ix":2},"p":{"a":0,"k":[0,0],"ix":3},"nm":"Ellipse Path 1","mn":"ADBE Vector Shape - Ellipse","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Secondary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":1,"lj":1,"ml":4,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,23.125],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":-1,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Ellipse 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":6,"ty":4,"nm":"Shape Layer 1","parent":3,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.21],"y":[0.543]},"o":{"x":[0.167],"y":[0.397]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.602]},"o":{"x":[0.79],"y":[0.46]},"t":18,"s":[90]},{"i":{"x":[0.21],"y":[0.539]},"o":{"x":[0.167],"y":[0.398]},"t":36,"s":[180]},{"i":{"x":[0.833],"y":[0.601]},"o":{"x":[0.79],"y":[0.462]},"t":54,"s":[270]},{"t":72,"s":[360]}],"ix":10},"p":{"a":0,"k":[60,60,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[430,430,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"d":1,"ty":"el","s":{"a":0,"k":[100,100],"ix":2},"p":{"a":0,"k":[0,0],"ix":3},"nm":"Ellipse Path 1","mn":"ADBE Vector Shape - Ellipse","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Primary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":1,"lj":1,"ml":4,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Ellipse 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":120,"st":0,"bm":0}],"markers":[]}');
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/components/CurrencyLogo/index.tsx
var CurrencyLogo = __webpack_require__(1208);
;// CONCATENATED MODULE: ./src/hooks/useAddTokenToMetaMask.ts



function useAddTokenToMetaMask(currencyToAdd) {
  const {
    chainId,
    library
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const token = currencyToAdd === null || currencyToAdd === void 0 ? void 0 : currencyToAdd.wrapped;
  const {
    0: success,
    1: setSuccess
  } = (0,external_react_.useState)();
  const addToken = (0,external_react_.useCallback)(() => {
    if (library && library.provider.isMetaMask && library.provider.request && token) {
      library.provider.request({
        method: 'wallet_watchAsset',
        params: {
          //@ts-ignore // need this for incorrect ethers provider type
          type: 'ERC20',
          options: {
            address: token.address,
            symbol: token.symbol,
            decimals: token.decimals,
            image: (0,CurrencyLogo/* getCurrencyLogoUrls */.N)(token)
          }
        }
      }).then(success => {
        setSuccess(success);
      }).catch(() => setSuccess(false));
    } else {
      setSuccess(false);
    }
  }, [library, token]);
  return {
    addToken,
    success
  };
}
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/modals/TransactionConfirmationModal/index.tsx

















const ConfirmationPendingContent = ({
  onDismiss,
  pendingText,
  pendingText2
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-end",
      children: /*#__PURE__*/jsx_runtime_.jsx(CloseIcon/* default */.Z, {
        onClick: onDismiss
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-24 pb-4 m-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx((external_lottie_react_default()), {
        animationData: loading_rolling_circle_namespaceObject,
        autoplay: true,
        loop: true
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-center justify-center gap-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-xl font-bold text-high-emphesis",
        children: i18n._(
        /*i18n*/
        i18n._("Waiting for Confirmation"))
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "font-bold",
        children: pendingText
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "font-bold",
        children: pendingText2
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-sm font-bold text-secondary",
        children: i18n._(
        /*i18n*/
        i18n._("Confirm this transaction in your wallet"))
      })]
    })]
  });
};
const TransactionSubmittedContent = ({
  onDismiss,
  chainId,
  hash,
  currencyToAdd
}) => {
  var _library$provider;

  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    library
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const {
    addToken,
    success
  } = useAddTokenToMetaMask(currencyToAdd);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-end",
      children: /*#__PURE__*/jsx_runtime_.jsx(CloseIcon/* default */.Z, {
        onClick: onDismiss
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-24 pb-4 m-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.ArrowUpCircle, {
        strokeWidth: 0.5,
        size: 90,
        className: "text-blue"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-center justify-center gap-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-xl font-bold",
        children: i18n._(
        /*i18n*/
        i18n._("Transaction Submitted"))
      }), chainId && hash && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
        href: (0,explorer/* getExplorerLink */.E)(chainId, hash, 'transaction'),
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "font-bold text-blue",
          children: "View on explorer"
        })
      }), currencyToAdd && (library === null || library === void 0 ? void 0 : (_library$provider = library.provider) === null || _library$provider === void 0 ? void 0 : _library$provider.isMetaMask) && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
        color: "gradient",
        onClick: addToken,
        className: "w-auto mt-4",
        children: !success ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(Row/* RowFixed */.DA, {
          className: "mx-auto space-x-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            children: i18n._(
            /*i18n*/
            i18n._("Add {0} to MetaMask", {
              0: currencyToAdd.symbol
            }))
          }), /*#__PURE__*/jsx_runtime_.jsx(Image/* default */.Z, {
            src: "/images/wallets/metamask.png",
            alt: i18n._(
            /*i18n*/
            i18n._("Add {0} to MetaMask", {
              0: currencyToAdd.symbol
            })),
            width: 24,
            height: 24,
            className: "ml-1"
          })]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(Row/* RowFixed */.DA, {
          children: [i18n._(
          /*i18n*/
          i18n._("Added")), " ", currencyToAdd.symbol]
        })
      })]
    })]
  });
};
const ConfirmationModalContent = ({
  title,
  bottomContent,
  onDismiss,
  topContent
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "grid gap-4",
    children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
      title: title,
      onClose: onDismiss
    }), topContent(), bottomContent()]
  });
};
const TransactionErrorContent = ({
  message,
  onDismiss
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "grid gap-6",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-lg font-medium text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Error"))
        }), /*#__PURE__*/jsx_runtime_.jsx(CloseIcon/* default */.Z, {
          onClick: onDismiss
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center justify-center gap-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.AlertTriangle, {
          className: "text-red",
          style: {
            strokeWidth: 1.5
          },
          size: 64
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "font-bold text-red",
          children: message
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
        color: "gradient",
        size: "lg",
        onClick: onDismiss,
        children: "Dismiss"
      })
    })]
  });
};

const TransactionConfirmationModal = ({
  isOpen,
  onDismiss,
  attemptingTxn,
  hash,
  pendingText,
  pendingText2,
  content,
  currencyToAdd
}) => {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  if (!chainId) return null; // confirmation screen

  return /*#__PURE__*/jsx_runtime_.jsx(Modal/* default */.Z, {
    isOpen: isOpen,
    onDismiss: onDismiss,
    maxHeight: 90,
    children: attemptingTxn ? /*#__PURE__*/jsx_runtime_.jsx(ConfirmationPendingContent, {
      onDismiss: onDismiss,
      pendingText: pendingText,
      pendingText2: pendingText2
    }) : hash ? /*#__PURE__*/jsx_runtime_.jsx(TransactionSubmittedContent, {
      chainId: chainId,
      hash: hash,
      onDismiss: onDismiss,
      currencyToAdd: currencyToAdd
    }) : content()
  });
};

/* harmony default export */ const modals_TransactionConfirmationModal = (TransactionConfirmationModal);

/***/ })

};
;
//# sourceMappingURL=615.js.map