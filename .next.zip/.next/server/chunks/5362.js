"use strict";
exports.id = 5362;
exports.ids = [5362];
exports.modules = {

/***/ 8223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports COLOR, SIZE */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


const COLOR = {
  default: '',
  blue: 'bg-blue bg-opacity-20 outline-blue rounded text-xs text-blue px-2 py-1',
  pink: 'bg-pink bg-opacity-20 outline-pink rounded text-xs text-pink px-2 py-1',
  gradient: 'bg-gradient-to-r from-blue to-pink opacity-80 hover:opacity-100 bg-pink bg-opacity-20 outline-pink rounded text-base text-white px-2 py-1'
};
const SIZE = {
  default: 'text-xs',
  medium: 'text-sm',
  large: 'text-lg'
};

function Badge({
  color = 'default',
  size = 'default',
  children,
  className = ''
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: `${COLOR[color]} ${SIZE[size]} ${className}`,
    children: children
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Badge);

/***/ }),

/***/ 4228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2047);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_device_detect__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const DoubleGlowShadow = ({
  children,
  className
}) => {
  if (react_device_detect__WEBPACK_IMPORTED_MODULE_0__.isMobile) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "shadow-swap",
      children: children
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)(className, 'relative w-full max-w-2xl'),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "relative filter drop-shadow",
      children: children
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DoubleGlowShadow);

/***/ }),

/***/ 4829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9202);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2503);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1446);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Tokens__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6269);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const denominator = (decimals = 18) => _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.exponentiate(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(decimals));

const viewUrl = `${_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.LAMBDA_URL}/orders/view`;

const viewFetcher = (url, account, chainId, pendingPage, page) => {
  return fetch(url, {
    method: 'POST',
    body: JSON.stringify({
      address: account,
      chainId,
      page,
      pendingPage
    })
  }).then(r => r.json()).then(j => j.data);
};

const useLimitOrders = () => {
  const {
    account,
    chainId
  } = (0,___WEBPACK_IMPORTED_MODULE_1__/* .useActiveWeb3React */ .aQ)();
  const limitOrderContract = (0,___WEBPACK_IMPORTED_MODULE_1__/* .useLimitOrderContract */ .JY)();
  const tokens = (0,_Tokens__WEBPACK_IMPORTED_MODULE_5__/* .useAllTokens */ .e_)();
  const {
    0: state,
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
    pending: {
      page: 1,
      maxPages: null,
      data: [],
      loading: true,
      totalOrders: 0
    },
    completed: {
      page: 1,
      maxPages: null,
      data: [],
      loading: true,
      totalOrders: 0
    }
  });
  const shouldFetch = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => viewUrl && account && chainId ? [viewUrl, account, chainId, state.pending.page, state.completed.page] : null, [account, chainId, state.completed.page, state.pending.page]);
  const {
    data: ordersData,
    mutate
  } = (0,swr__WEBPACK_IMPORTED_MODULE_3__/* .default */ .ZP)(shouldFetch, viewFetcher);
  const setPendingPage = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(page => {
    setState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
      pending: _objectSpread(_objectSpread({}, prevState.pending), {}, {
        page,
        loading: true
      })
    }));
  }, []);
  const setCompletedPage = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(page => {
    setState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
      completed: _objectSpread(_objectSpread({}, prevState.completed), {}, {
        page,
        loading: true
      })
    }));
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (!account || !chainId || !ordersData || !ordersData.pendingOrders || !ordersData.otherOrders || !Array.isArray(ordersData.pendingOrders.orders) || !Array.isArray(ordersData.otherOrders.orders)) return;

    const transform = async order => {
      const limitOrder = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.LimitOrder.getLimitOrder(_objectSpread(_objectSpread({}, order), {}, {
        chainId: +order.chainId,
        tokenInDecimals: +order.tokenInDecimals,
        tokenOutDecimals: +order.tokenOutDecimals
      }));
      const tokenIn = limitOrder.amountIn.currency;
      const tokenOut = limitOrder.amountOut.currency;
      const openOrder = {
        tokenIn: tokens[tokenIn.address] || new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(chainId, tokenIn.address.toLowerCase(), tokenIn.decimals, tokenIn.symbol),
        tokenOut: tokens[tokenOut.address] || new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(chainId, tokenOut.address.toLowerCase(), tokenOut.decimals, tokenOut.symbol),
        limitOrder,
        filledPercent: order.filledAmount ? order.filledAmount.mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__.BigNumber.from('100')).div(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__.BigNumber.from(order.amountIn)).toString() : '0',
        status: order.status,
        rate: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(limitOrder.amountOut.quotient, denominator(tokenOut.decimals)).divide(new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(limitOrder.amountIn.quotient, denominator(tokenIn.decimals))).divide(denominator(2)).toSignificant(6)
      };
      return openOrder;
    };

    (async () => {
      const openOrders = await Promise.all(ordersData.pendingOrders.orders.map(el => transform(el)));
      const completedOrders = await Promise.all(ordersData.otherOrders.orders.map(el => transform(el)));
      setState(prevState => ({
        pending: _objectSpread(_objectSpread({}, prevState.pending), {}, {
          data: openOrders,
          maxPages: ordersData.pendingOrders.pendingOrderMaxPage,
          loading: false,
          totalOrders: ordersData.pendingOrders.totalPendingOrders
        }),
        completed: _objectSpread(_objectSpread({}, prevState.completed), {}, {
          data: completedOrders,
          maxPages: ordersData.otherOrders.maxPage,
          loading: false,
          totalOrders: ordersData.otherOrders.totalOrders
        })
      }));
    })(); // eslint-disable-next-line react-hooks/exhaustive-deps

  }, [account, chainId, ordersData, limitOrderContract, setPendingPage, setCompletedPage]);
  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => _objectSpread(_objectSpread({}, state), {}, {
    pending: _objectSpread(_objectSpread({}, state.pending), {}, {
      setPage: setPendingPage
    }),
    completed: _objectSpread(_objectSpread({}, state.completed), {}, {
      setPage: setCompletedPage
    }),
    mutate
  }), [mutate, setCompletedPage, setPendingPage, state]);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useLimitOrders);

/***/ })

};
;
//# sourceMappingURL=5362.js.map