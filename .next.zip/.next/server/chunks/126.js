"use strict";
exports.id = 126;
exports.ids = [126];
exports.modules = {

/***/ 7603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "gn": () => (/* binding */ ButtonConfirmed),
/* harmony export */   "Kd": () => (/* binding */ ButtonError)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["children", "className", "color", "size", "variant"],
      _excluded2 = ["confirmed", "disabled"],
      _excluded3 = ["error", "disabled"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const SIZE = {
  xs: 'px-2 py-1 text-xs',
  sm: 'px-4 py-2 text-base',
  default: 'px-4 py-3 text-base',
  lg: 'px-6 py-4 text-base',
  none: 'p-0 text-base'
};
const FILLED = {
  default: 'bg-transparent opacity-80 hover:opacity-100',
  red: 'bg-red bg-opacity-80 w-full rounded text-high-emphesis hover:bg-opacity-100 disabled:bg-opacity-80',
  blue: 'bg-blue bg-opacity-80 w-full rounded text-high-emphesis hover:bg-opacity-100 disabled:bg-opacity-80',
  pink: 'bg-gradient-to-r from-pink to-opaque-pink w-full rounded text-high-emphesis opacity-80 hover:opacity-100 disabled:bg-opacity-80',
  gray: 'border rounded shadow-sm focus:ring-2 focus:ring-offset-2 bg-dark-700 bg-opacity-80 w-full text-primary border-dark-800 hover:bg-opacity-100 focus:ring-offset-dark-700 focus:ring-dark-800 disabled:bg-opacity-80',
  green: 'bg-green bg-opacity-80 w-full rounded text-high-emphesis hover:bg-opacity-100 disabled:bg-opacity-80',
  gradient: 'w-full text-high-emphesis bg-gradient-to-r from-blue to-pink opacity-80 hover:opacity-100 disabled:bg-opacity-80'
};
const OUTLINED = {
  default: 'bg-transparent opacity-80 hover:opacity-100',
  red: 'bg-red bg-opacity-20 outline-red rounded text-red hover:bg-opacity-40 disabled:bg-opacity-20',
  blue: 'bg-blue bg-opacity-20 outline-blue rounded text-blue hover:bg-opacity-40 disabled:bg-opacity-20',
  pink: 'bg-pink bg-opacity-20 outline-pink rounded text-pink hover:bg-opacity-40 disabled:bg-opacity-20',
  gray: 'bg-dark-700 bg-opacity-20 outline-gray rounded text-gray hover:bg-opacity-40 disabled:bg-opacity-20',
  green: 'bg-green bg-opacity-20 border border-green rounded text-green hover:bg-opacity-40 disabled:bg-opacity-20',
  gradient: 'border border-transparent border-gradient-r-blue-pink-dark-900 opacity-80 hover:opacity-100 disabled:bg-opacity-20'
};
const EMPTY = {
  default: 'flex bg-transparent justify-center items-center disabled:opacity-50 disabled:cursor-auto bg-opacity-80 hover:bg-opacity-100'
};
const LINK = {
  default: 'text-primary hover:text-high-emphesis focus:text-high-emphesis whitespace-nowrap focus:ring-0',
  blue: 'text-blue text-opacity-80 hover:text-opacity-100 focus:text-opacity-100 whitespace-nowrap focus:ring-0'
};
const VARIANT = {
  outlined: OUTLINED,
  filled: FILLED,
  empty: EMPTY,
  link: LINK
};

function Button(_ref) {
  let {
    children,
    className = undefined,
    color = 'default',
    size = 'default',
    variant = 'filled'
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("button", _objectSpread(_objectSpread({
    className: (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)(VARIANT[variant][color], variant !== 'empty' && SIZE[size], 'rounded disabled:cursor-not-allowed focus:outline-none', // 'rounded focus:outline-none focus:ring disabled:opacity-50 disabled:cursor-not-allowed font-medium',
    className)
  }, rest), {}, {
    children: children
  }));
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);
function ButtonConfirmed(_ref2) {
  let {
    confirmed,
    disabled
  } = _ref2,
      rest = _objectWithoutProperties(_ref2, _excluded2);

  if (confirmed) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Button, _objectSpread({
      variant: "outlined",
      color: "green",
      size: "lg",
      className: (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)(disabled && 'cursor-not-allowed', 'border opacity-50'),
      disabled: disabled
    }, rest));
  } else {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Button, _objectSpread({
      color: disabled ? 'gray' : 'gradient',
      size: "lg",
      disabled: disabled
    }, rest));
  }
}
function ButtonError(_ref3) {
  let {
    error,
    disabled
  } = _ref3,
      rest = _objectWithoutProperties(_ref3, _excluded3);

  if (error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Button, _objectSpread({
      color: "red",
      size: "lg"
    }, rest));
  } else {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Button, _objectSpread({
      color: disabled ? 'gray' : 'gradient',
      disabled: disabled,
      size: "lg"
    }, rest));
  }
}

/***/ }),

/***/ 5857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lM": () => (/* binding */ BASES_TO_CHECK_TRADES_AGAINST),
/* harmony export */   "ck": () => (/* binding */ ADDITIONAL_BASES),
/* harmony export */   "IP": () => (/* binding */ CUSTOM_BASES),
/* harmony export */   "gP": () => (/* binding */ COMMON_BASES),
/* harmony export */   "xu": () => (/* binding */ BASES_TO_TRACK_LIQUIDITY_FOR),
/* harmony export */   "Q8": () => (/* binding */ PINNED_PAIRS)
/* harmony export */ });
/* harmony import */ var _config_tokens__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9575);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // a list of tokens by chain


// List of all mirror's assets addresses.
// Last pulled from : https://whitelist.mirror.finance/eth/tokenlists.json
// TODO: Generate this programmatically ?
const MIRROR_ADDITIONAL_BASES = {
  [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST.address */ .bi.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td],
  [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR.address */ .Td.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  '0xd36932143F6eBDEDD872D5Fb0651f4B72Fd15a84': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mAAPL
  '0x59A921Db27Dd6d4d974745B7FfC5c33932653442': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mGOOGL
  '0x21cA39943E91d704678F5D00b6616650F066fD63': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mTSLA
  '0xC8d674114bac90148d11D3C1d33C61835a0F9DCD': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mNFLX
  '0x13B02c8dE71680e71F0820c996E4bE43c2F57d15': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mQQQ
  '0xEdb0414627E6f1e3F082DE65cD4F9C693D78CCA9': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mTWTR
  '0x41BbEDd7286dAab5910a1f15d12CBda839852BD7': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mMSFT
  '0x0cae9e4d663793c2a2A0b211c1Cf4bBca2B9cAa7': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mAMZN
  '0x56aA298a19C93c6801FDde870fA63EF75Cc0aF72': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mBABA
  '0x1d350417d9787E000cc1b95d70E9536DcD91F373': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mIAU
  '0x9d1555d8cB3C846Bb4f7D5B1B1080872c3166676': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mSLV
  '0x31c63146a635EB7465e5853020b39713AC356991': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mUSO
  '0xf72FCd9DCF0190923Fadd44811E240Ef4533fc86': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi] // mVIXY

}; // TODO: SDK should have two maps, WETH map and WNATIVE map.

const WRAPPED_NATIVE_ONLY = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]]
}; // used to construct intermediary pairs for trading

const BASES_TO_CHECK_TRADES_AGAINST = _objectSpread(_objectSpread({}, WRAPPED_NATIVE_ONLY), {}, {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .RUNE */ .uj, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .NFTX */ .lK, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .STETH */ ._S],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDC */ .W3.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WBTC */ .W3.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DAI */ .W3.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WETH */ .W3.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDT */ .W3.USDT],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.DAI */ .of.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.USDC */ .of.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WBTC */ .of.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WETH */ .of.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.DAI */ .Su.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USD */ .Su.USD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDC */ .Su.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDT */ .Su.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.BTCB */ .Su.BTCB, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.WETH */ .Su.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ARBITRUM.WBTC */ .PO.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ARBITRUM.USDC */ .PO.USDC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDC */ .AC.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDT */ .AC.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WBTC */ .AC.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WETH */ .AC.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI */ .Qz.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT */ .Qz.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC */ .Qz.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH */ .Qz.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDC */ .Qz.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI_OLD */ .Qz.DAI_OLD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT_OLD */ .Qz.USDT_OLD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC_OLD */ .Qz.WBTC_OLD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH_OLD */ .Qz.WETH_OLD],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.DAI */ ._T.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDC */ ._T.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDT */ ._T.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WBTC */ ._T.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WETH */ ._T.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.DAI */ .rs.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDC */ .rs.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDT */ .rs.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WBTC */ .rs.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WETH */ .rs.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.DAI */ .Xn.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDC */ .Xn.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDT */ .Xn.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WBTC */ .Xn.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WETH */ .Xn.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cETH */ .T5.cETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mCUSD */ .T5.mCUSD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mCELO */ .T5.mCELO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mcEURO */ .T5.mcEURO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cUSD */ .T5.cUSD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cEURO */ .T5.cEURO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cBTC */ .T5.cBTC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PALM.WETH */ .EA.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PALM.DAI */ .EA.DAI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]]
});
const ADDITIONAL_BASES = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: _objectSpread(_objectSpread({}, MIRROR_ADDITIONAL_BASES), {}, {
    '0xF16E4d813f4DcfDe4c5b44f305c908742De84eF0': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ETH2X_FLI */ .Lp],
    '0xe379a60A8FC7C9DD161887fFADF3054790576c8D': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XSUSHI */ .LL],
    // XSUSHI 25 Call [30 June 2021]
    '0xB46F57e7Ce3a284d74b70447Ef9352B5E5Df8963': [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UMA */ .iD],
    // UMA 25 Call [30 June 2021]
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FEI.address */ .sr.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DPI */ .g8],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FRAX.address */ .BN.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FXS */ .xn],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FXS.address */ .xn.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FRAX */ .BN],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC.address */ .ML.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .RENBTC */ .vS],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .RENBTC.address */ .vS.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PONT.address */ .YY.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PWING */ .Wg],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PWING.address */ .Wg.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PONT */ .YY],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PLAY.address */ .NH.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DOUGH */ .du],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DOUGH.address */ .du.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PLAY */ .NH],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .IBETH.address */ .yl.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ALPHA */ .Xe],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ALPHA.address */ .Xe.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .IBETH */ .yl],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HBTC.address */ .y7.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CREAM */ .rK],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CREAM.address */ .rK.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HBTC */ .y7],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DUCK.address */ .IE.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDP */ .Es],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDP.address */ .Es.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DUCK */ .IE],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAB.address */ ._C.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAC */ .mf],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAC.address */ .mf.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAB */ ._C],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LIFT.address */ .t3.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LFBTC */ .iI],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LFBTC.address */ .iI.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LIFT */ .t3],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CVXCRV.address */ .Wo.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CRV */ .be],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CRV.address */ .be.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CVXCRV */ .Wo]
  }),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: {
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FRAX.address */ .W3.FRAX.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FXS */ .W3.FXS],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FXS.address */ .W3.FXS.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FRAX */ .W3.FRAX],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DRAX.address */ .W3.DRAX.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DMAGIC */ .W3.DMAGIC],
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.AXMATIC.address */ .W3.AXMATIC.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DMAGIC */ .W3.DMAGIC] //[MATIC.DMAGIC.address]: [MATIC.DRAX, MATIC.AXMATIC],

  }
};
/**
 * Some tokens can only be swapped via certain pairs, so we override the list of bases that are considered for these
 * tokens.
 */

const CUSTOM_BASES = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: {
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AMPL.address */ .s5.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]]
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: {
    [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.TEL.address */ .W3.TEL.address]: [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.SUSHI */ .W3.SUSHI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.AAVE */ .W3.AAVE]
  }
};
/**
 * Shows up in the currency select for swap and add liquidity
 */

const COMMON_BASES = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDC */ .W3.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WBTC */ .W3.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DAI */ .W3.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WETH */ .W3.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDT */ .W3.USDT // SUSHI[ChainId.MATIC],
  ],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.DAI */ .of.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.USDC */ .of.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WBTC */ .of.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WETH */ .of.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.DAI */ .Su.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USD */ .Su.USD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDC */ .Su.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDT */ .Su.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.BTCB */ .Su.BTCB, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.WETH */ .Su.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ARBITRUM.WBTC */ .PO.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ARBITRUM.USDC */ .PO.USDC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDC */ .AC.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDT */ .AC.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WBTC */ .AC.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WETH */ .AC.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI */ .Qz.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT */ .Qz.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC */ .Qz.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH */ .Qz.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDC */ .Qz.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.DAI */ ._T.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDC */ ._T.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDT */ ._T.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WETH */ ._T.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WBTC */ ._T.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.DAI */ .rs.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDC */ .rs.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDT */ .rs.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WBTC */ .rs.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WETH */ .rs.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.DAI */ .Xn.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDC */ .Xn.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDT */ .Xn.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WBTC */ .Xn.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WETH */ .Xn.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cETH */ .T5.cETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cUSD */ .T5.cUSD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cEURO */ .T5.cEURO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cBTC */ .T5.cBTC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PALM.WETH */ .EA.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PALM.DAI */ .EA.DAI]
}; // used to construct the list of all pairs we consider by default in the frontend

const BASES_TO_TRACK_LIQUIDITY_FOR = _objectSpread(_objectSpread({}, WRAPPED_NATIVE_ONLY), {}, {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDC */ .W3.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WBTC */ .W3.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DAI */ .W3.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WETH */ .W3.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDT */ .W3.USDT],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.DAI */ .of.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.USDC */ .of.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WBTC */ .of.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WETH */ .of.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.DAI */ .Su.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USD */ .Su.USD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDC */ .Su.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDT */ .Su.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.BTCB */ .Su.BTCB, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.WETH */ .Su.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ARBITRUM.WBTC */ .PO.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ARBITRUM.USDC */ .PO.USDC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDC */ .AC.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDT */ .AC.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WBTC */ .AC.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WETH */ .AC.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI */ .Qz.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT */ .Qz.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC */ .Qz.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH */ .Qz.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDC */ .Qz.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI_OLD */ .Qz.DAI_OLD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT_OLD */ .Qz.USDT_OLD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC_OLD */ .Qz.WBTC_OLD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH_OLD */ .Qz.WETH_OLD],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.DAI */ ._T.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDC */ ._T.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDT */ ._T.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WBTC */ ._T.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WETH */ ._T.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.DAI */ .rs.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDC */ .rs.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDT */ .rs.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WBTC */ .rs.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WETH */ .rs.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.DAI */ .Xn.DAI, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDC */ .Xn.USDC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDT */ .Xn.USDT, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WBTC */ .Xn.WBTC, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WETH */ .Xn.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cETH */ .T5.cETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mCUSD */ .T5.mCUSD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mCELO */ .T5.mCELO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mcEURO */ .T5.mcEURO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cUSD */ .T5.cUSD, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cEURO */ .T5.cEURO, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cBTC */ .T5.cBTC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONRIVER]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.PALM], _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PALM.WETH */ .EA.WETH, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PALM.DAI */ .EA.DAI]
});
const PINNED_PAIRS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [[_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]], [new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET, '0x5d3a536E4D6DbD6114cc1Ead35777bAB948E3643', 8, 'cDAI', 'Compound Dai'), new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET, '0x39AA39c021dfbaE8faC545936693aC917d5E7563', 8, 'cUSDC', 'Compound USD Coin')], [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA], [_config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _config_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA]]
};

/***/ }),

/***/ 9575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PO": () => (/* binding */ ARBITRUM),
/* harmony export */   "EA": () => (/* binding */ PALM),
/* harmony export */   "T5": () => (/* binding */ CELO),
/* harmony export */   "Su": () => (/* binding */ BSC),
/* harmony export */   "of": () => (/* binding */ FANTOM),
/* harmony export */   "W3": () => (/* binding */ MATIC),
/* harmony export */   "Xn": () => (/* binding */ OKEX),
/* harmony export */   "rs": () => (/* binding */ HECO),
/* harmony export */   "_T": () => (/* binding */ HARMONY),
/* harmony export */   "AC": () => (/* binding */ XDAI),
/* harmony export */   "Qz": () => (/* binding */ AVALANCHE),
/* harmony export */   "Xe": () => (/* binding */ ALPHA),
/* harmony export */   "s5": () => (/* binding */ AMPL),
/* harmony export */   "_C": () => (/* binding */ BAB),
/* harmony export */   "mf": () => (/* binding */ BAC),
/* harmony export */   "rK": () => (/* binding */ CREAM),
/* harmony export */   "h1": () => (/* binding */ DAI),
/* harmony export */   "du": () => (/* binding */ DOUGH),
/* harmony export */   "IE": () => (/* binding */ DUCK),
/* harmony export */   "Lp": () => (/* binding */ ETH2X_FLI),
/* harmony export */   "sr": () => (/* binding */ FEI),
/* harmony export */   "BN": () => (/* binding */ FRAX),
/* harmony export */   "xn": () => (/* binding */ FXS),
/* harmony export */   "y7": () => (/* binding */ HBTC),
/* harmony export */   "yl": () => (/* binding */ IBETH),
/* harmony export */   "PY": () => (/* binding */ MEOW),
/* harmony export */   "Td": () => (/* binding */ MIR),
/* harmony export */   "lK": () => (/* binding */ NFTX),
/* harmony export */   "NH": () => (/* binding */ PLAY),
/* harmony export */   "YY": () => (/* binding */ PONT),
/* harmony export */   "Wg": () => (/* binding */ PWING),
/* harmony export */   "vS": () => (/* binding */ RENBTC),
/* harmony export */   "uj": () => (/* binding */ RUNE),
/* harmony export */   "_S": () => (/* binding */ STETH),
/* harmony export */   "iD": () => (/* binding */ UMA),
/* harmony export */   "gn": () => (/* binding */ USDC),
/* harmony export */   "Es": () => (/* binding */ USDP),
/* harmony export */   "AA": () => (/* binding */ USDT),
/* harmony export */   "bi": () => (/* binding */ UST),
/* harmony export */   "ML": () => (/* binding */ WBTC),
/* harmony export */   "LL": () => (/* binding */ XSUSHI),
/* harmony export */   "UP": () => (/* binding */ LICP),
/* harmony export */   "hY": () => (/* binding */ ICP20),
/* harmony export */   "aK": () => (/* binding */ ST_ICP),
/* harmony export */   "t3": () => (/* binding */ LIFT),
/* harmony export */   "iI": () => (/* binding */ LFBTC),
/* harmony export */   "Wo": () => (/* binding */ CVXCRV),
/* harmony export */   "be": () => (/* binding */ CRV),
/* harmony export */   "g8": () => (/* binding */ DPI),
/* harmony export */   "hs": () => (/* binding */ SUSHI)
/* harmony export */ });
/* unused harmony exports TRIBE, UMA_CALL, XSUSHI_CALL, CRXSUSHI, AXSUSHI, WETH9_EXTENDED */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const ARBITRUM = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM, '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8', 6, 'USDC', 'USD Coin'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM, '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f', 8, 'WBTC', 'Wrapped Bitcoin')
};
const PALM = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM, '0x4C1f6fCBd233241bF2f4D02811E3bF8429BC27B8', 18, 'DAI', 'Dai Stablecoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM, '0x726138359C17F1E56bA8c4F737a7CAf724F6010b', 18, 'WETH', 'Wrapped Ether')
};
const CELO = {
  mCUSD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x64dEFa3544c695db8c535D289d843a189aa26b98', 18, 'mCUSD', 'Moola cUSD'),
  mCELO: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x7037F7296B2fc7908de7b57a89efaa8319f0C500', 18, 'mCELO', 'Moola CELO'),
  mcEURO: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0xa8d0E6799FF3Fd19c6459bf02689aE09c4d78Ba7', 18, 'mCEUR', 'Moola Celo Euro'),
  cUSD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x765DE816845861e75A25fCA122bb6898B8B1282a', 18, 'cUSD', 'Celo Dollar'),
  cEURO: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0xD8763CBa276a3738E6DE85b4b3bF5FDed6D6cA73', 18, 'cEUR', 'Celo Euro'),
  cBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0xD629eb00dEced2a080B7EC630eF6aC117e614f1b', 18, 'cBTC', 'Wrapped Bitcoin'),
  cETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x2DEf4285787d58a2f811AF24755A8150622f4361', 18, 'cETH', 'Wrapped Ether')
};
const BSC = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3', 18, 'DAI', 'Dai Stablecoin'),
  USD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', 18, 'BUSD', 'Binance USD'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', 18, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x55d398326f99059fF775485246999027B3197955', 18, 'USDT', 'Tether USD'),
  BTCB: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', 18, 'BTCB', 'Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x2170Ed0880ac9A755fd29B2688956BD959F933F8', 18, 'WETH', 'Wrapped Ether')
};
const FANTOM = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x04068DA6C83AFCFA0e13ba15A6696662335D5B75', 6, 'USDC', 'USD Coin'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x321162Cd933E2Be498Cd2267a90534A804051b11', 8, 'WBTC', 'Wrapped Bitcoin'),
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x8D11eC38a3EB5E956B052f67Da8Bdc9bef8Abf3E', 18, 'DAI', 'Dai Stablecoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x74b23882a30290451A17c44f4F05243b6b58C76d', 18, 'WETH', 'Wrapped Ether')
};
const MATIC = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', 6, 'USDC', 'USD Coin'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6', 8, 'WBTC', 'Wrapped Bitcoin'),
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063', 18, 'DAI', 'Dai Stablecoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619', 18, 'WETH', 'Wrapped Ether'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', 6, 'USDT', 'Tether USD'),
  TEL: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xdF7837DE1F2Fa4631D716CF2502f8b230F1dcc32', 2, 'TEL', 'Telcoin'),
  SUSHI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x0b3F868E0BE5597D5DB7fEB59E1CADBb0fdDa50a', 18, 'SUSHI', 'SushiToken'),
  AAVE: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xD6DF932A45C0f255f85145f286eA0b292B21C90B', 18, 'AAVE', 'Aave'),
  FRAX: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x104592a158490a9228070E0A8e5343B499e125D0', 18, 'FRAX', 'Frax'),
  FXS: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x3e121107F6F22DA4911079845a470757aF4e1A1b', 18, 'FXS', 'Frax Share'),
  DMAGIC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x61dAECaB65EE2A1D5b6032df030f3fAA3d116Aa7', 18, 'DMAGIC', 'Dark Magic'),
  DRAX: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x1Ba3510A9ceEb72E5CdBa8bcdDe9647E1f20fB4b', 18, 'DRAX', 'Drax'),
  AXMATIC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x1221591c1d77A9c334aBb0fe530ae6EE3aF51Af9', 18, 'AXMATIC', 'axMATIC')
};
const OKEX = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0x21cDE7E32a6CAF4742d00d44B07279e7596d26B9', 18, 'DAI', 'Dai Stablecoin'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0xc946DAf81b08146B1C7A8Da2A851Ddf2B3EAaf85', 18, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0x382bB369d343125BfB2117af9c149795C6C65C50', 18, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0x506f731F7656e2FB34b587B912808f2a7aB640BD', 18, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0xEF71CA2EE68F45B9Ad6F72fbdb33d707b872315C', 18, 'WETH', 'Wrapped Ether')
};
const HECO = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x3D760a45D0887DFD89A2F5385a236B29Cb46ED2a', 18, 'DAI', 'Dai Stablecoin'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x9362Bbef4B8313A8Aa9f0c9808B80577Aa26B73B', 18, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0xa71EdC38d189767582C38A3145b5873052c3e47a', 18, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x66a79D23E58475D2738179Ca52cd0b41d73f0BEa', 18, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x64FF637fB478863B7468bc97D30a5bF3A428a1fD', 18, 'WETH', 'Wrapped Ether')
};
const HARMONY = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0xEf977d2f931C1978Db5F6747666fa1eACB0d0339', 18, 'DAI', 'Dai Stablecoin'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x985458E523dB3d53125813eD68c274899e9DfAb4', 6, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x3C2B8Be99c50593081EAA2A724F0B8285F5aba8f', 6, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x3095c7557bCb296ccc6e363DE01b760bA031F2d9', 8, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x6983D1E6DEf3690C4d616b13597A09e6193EA013', 18, 'WETH', 'Wrapped Ether')
};
const XDAI = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0xDDAfbb505ad214D7b80b1f830fcCc89B60fb7A83', 6, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0x4ECaBa5870353805a9F068101A40E0f32ed605C6', 6, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0x8e5bBbb09Ed1ebdE8674Cda39A0c169401db4252', 8, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0x6A023CCd1ff6F2045C3309768eAd9E68F978f6e1', 18, 'WETH', 'Wrapped Ether')
};
const AVALANCHE = {
  DAI_OLD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xbA7dEebBFC5fA1100Fb055a87773e1E99Cd3507a', 18, 'DAI', 'Dai Stablecoin Old'),
  USDT_OLD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xde3A24028580884448a5397872046a019649b084', 6, 'USDT', 'Tether USD Old'),
  WBTC_OLD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0x408D4cD0ADb7ceBd1F1A1C33A0Ba2098E1295bAB', 8, 'WBTC', 'Wrapped Bitcoin Old'),
  WETH_OLD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xf20d962a6c8f70c731bd838a3a388D7d48fA6e15', 18, 'WETH', 'Wrapped Ether Old'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xA7D7079b0FEaD91F3e65f86E8915Cb59c1a4C664', 6, 'USDC/e', 'USD Coin'),
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xd586E7F844cEa2F87f50152665BCbc2C279D8d70', 18, 'DAI/e', 'Dai Stablecoin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xc7198437980c041c805A1EDcbA50c1Ce5db95118', 6, 'USDT/e', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0x50b7545627a5162F82A992c33b87aDc75187B218', 8, 'WBTC/e', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0x49D5c2BdFfac6CE2BFdB6640F4F80f226bc10bAB', 18, 'WETH/e', 'Wrapped Ether')
}; // Default Ethereum chain tokens

const ALPHA = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xa1faa113cbE53436Df28FF0aEe54275c13B40975', 18, 'ALPHA', 'AlphaToken');
const AMPL = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xD46bA6D942050d489DBd938a2C909A5d5039A161', 9, 'AMPL', 'Ampleforth');
const BAB = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xC36824905dfF2eAAEE7EcC09fCC63abc0af5Abc5', 18, 'BAB', 'BAB');
const BAC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x3449FC1Cd036255BA1EB19d65fF4BA2b8903A69a', 18, 'BAC', 'Basis Cash');
const CREAM = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x2ba592F78dB6436527729929AAf6c908497cB200', 18, 'CREAM', 'Cream');
const DAI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x6B175474E89094C44Da98b954EedeAC495271d0F', 18, 'DAI', 'Dai Stablecoin');
const DOUGH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xad32A8e6220741182940c5aBF610bDE99E737b2D', 18, 'DOUGH', 'PieDAO Dough v2');
const DUCK = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x92E187a03B6CD19CB6AF293ba17F2745Fd2357D5', 18, 'DUCK', 'DUCK');
const ETH2X_FLI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xAa6E8127831c9DE45ae56bB1b0d4D4Da6e5665BD', 18, 'ETH2x-FLI', 'ETH 2x Flexible Leverage Index');
const FEI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x956F47F50A910163D8BF957Cf5846D573E7f87CA', 18, 'FEI', 'Fei USD');
const FRAX = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x853d955aCEf822Db058eb8505911ED77F175b99e', 18, 'FRAX', 'FRAX');
const FXS = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0', 18, 'FXS', 'Frax Share');
const HBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x0316EB71485b0Ab14103307bf65a021042c6d380', 18, 'HBTC', 'Huobi BTC');
const IBETH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xeEa3311250FE4c3268F8E684f7C87A82fF183Ec1', 8, 'ibETHv2', 'Interest Bearing Ether v2');
const MEOW = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x650F44eD6F1FE0E1417cb4b3115d52494B4D9b6D', 18, 'MEOW', 'Meowshi');
const MIR = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x09a3EcAFa817268f77BE1283176B946C4ff2E608', 18, 'MIR', 'Wrapped MIR');
const NFTX = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x87d73E916D7057945c9BcD8cdd94e42A6F47f776', 18, 'NFTX', 'NFTX');
const PLAY = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x33e18a092a93ff21aD04746c7Da12e35D34DC7C4', 18, 'PLAY', 'Metaverse NFT Index');
const PONT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xcb46C550539ac3DB72dc7aF7c89B11c306C727c2', 9, 'pONT', 'Poly Ontology Token');
const PWING = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xDb0f18081b505A7DE20B18ac41856BCB4Ba86A1a', 9, 'pWING', 'Poly Ontology Wing Token');
const RENBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(1, '0xEB4C2781e4ebA804CE9a9803C67d0893436bB27D', 8, 'renBTC', 'renBTC');
const RUNE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x3155BA85D5F96b2d030a4966AF206230e46849cb', 18, 'RUNE', 'RUNE.ETH');
const STETH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xDFe66B14D37C77F4E9b180cEb433d1b164f0281D', 18, 'stETH', 'stakedETH');
const TRIBE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xc7283b66Eb1EB5FB86327f08e1B5816b0720212B', 18, 'TRIBE', 'Tribe');
const UMA = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x04Fa0d235C4abf4BcF4787aF4CF447DE572eF828', 18, 'UMA', 'UMA');
const UMA_CALL = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x1062aD0E59fa67fa0b27369113098cC941Dd0D5F', 18, 'UMA', 'UMA 35 Call [30 Apr 2021]');
const USDC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6, 'USDC', 'USD Coin');
const USDP = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x1456688345527bE1f37E9e627DA0837D6f08C925', 18, 'USDP', 'USDP Stablecoin');
const USDT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xdAC17F958D2ee523a2206206994597C13D831ec7', 6, 'USDT', 'Tether USD');
const UST = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xa47c8bf37f92aBed4A126BDA807A7b7498661acD', 18, 'UST', 'Wrapped UST');
const XSUSHI_CALL = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xada279f9301C01A4eF914127a6C2a493Ad733924', 18, 'XSUc25-0531', 'XSUSHI 25 Call [31 May 2021]');
const WBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599', 8, 'WBTC', 'Wrapped BTC');
const XSUSHI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272', 18, 'xSUSHI', 'SushiBar');
const LICP = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x1b43b97094aa3c6cc678edb9e28ac67daaa7cc64', 18, 'LICP', 'Liquid ICP');
const ICP20 = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xd63568e4bcb3d32c928e243e2bdb9e272d748a06', 18, 'ICP-20', 'Wrapped ICP');
const ST_ICP = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xe7946921c619F5D9E8f28E3A5B4d218e9520dD11', 18, 'st-ICP', 'ICPBar');
const LIFT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xf9209d900f7ad1DC45376a2caA61c78f6dEA53B6', 18, 'LIFT', 'LiftKitchen');
const LFBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xafcE9B78D409bF74980CACF610AFB851BF02F257', 18, 'LFBTC', 'LiftKitchen BTC');
const CVXCRV = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x62B9c7356A2Dc64a1969e19C23e4f579F9810Aa7', 18, 'cvxCRV', 'cvxCRV');
const CRV = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xD533a949740bb3306d119CC777fa900bA034cd52', 18, 'CRV', 'Curve');
const CRXSUSHI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x228619cca194fbe3ebeb2f835ec1ea5080dafbb2', 8, 'crXSUSHI', 'Cream SushiBar');
const AXSUSHI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xf256cc7847e919fac9b808cc216cac87ccf2f47a', 18, 'aXSUSHI', 'Aave interest bearing XSUSHI');
const DPI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x1494CA1F11D487c2bBe4543E90080AeBa4BA3C2b', 18, 'DefiPulse', 'DPI');
// SUSHI
const SUSHI = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"], _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO], 18, 'SUSHI', 'SushiToken')
};
const WETH9_EXTENDED = _objectSpread(_objectSpread({}, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH9), {}, {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET, '0x4A5e4A42dC430f669086b417AADf2B128beFEfac', 18, 'WETH9', 'Wrapped Ether'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM, '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1', 18, 'WETH', 'Wrapped Ether'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83', 18, 'WFTM', 'Wrapped Fantom')
});

/***/ }),

/***/ 5899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ki": () => (/* binding */ createTokenFilterFunction),
/* harmony export */   "ls": () => (/* binding */ filterTokens),
/* harmony export */   "T2": () => (/* binding */ useSortedTokensByQuery)
/* harmony export */ });
/* harmony import */ var _validate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2556);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const alwaysTrue = () => true;
/**
 * Create a filter function to apply to a token for whether it matches a particular search query
 * @param search the search query to apply to the token
 */


function createTokenFilterFunction(search) {
  const searchingAddress = (0,_validate__WEBPACK_IMPORTED_MODULE_0__/* .isAddress */ .UJ)(search);

  if (searchingAddress) {
    const lower = searchingAddress.toLowerCase();
    return t => 'isToken' in t ? searchingAddress === t.address : lower === t.address.toLowerCase();
  }

  const lowerSearchParts = search.toLowerCase().split(/\s+/).filter(s => s.length > 0);
  if (lowerSearchParts.length === 0) return alwaysTrue;

  const matchesSearch = s => {
    const sParts = s.toLowerCase().split(/\s+/).filter(s => s.length > 0);
    return lowerSearchParts.every(p => p.length === 0 || sParts.some(sp => sp.startsWith(p) || sp.endsWith(p)));
  };

  return ({
    name,
    symbol
  }) => Boolean(symbol && matchesSearch(symbol) || name && matchesSearch(name));
}
function filterTokens(tokens, search) {
  return tokens.filter(createTokenFilterFunction(search));
}
function useSortedTokensByQuery(tokens, searchQuery) {
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => {
    if (!tokens) {
      return [];
    }

    const symbolMatch = searchQuery.toLowerCase().split(/\s+/).filter(s => s.length > 0);

    if (symbolMatch.length > 1) {
      return tokens;
    }

    const exactMatches = [];
    const symbolSubtrings = [];
    const rest = []; // sort tokens by exact match -> subtring on symbol match -> rest

    tokens.map(token => {
      var _token$symbol, _token$symbol2;

      if (((_token$symbol = token.symbol) === null || _token$symbol === void 0 ? void 0 : _token$symbol.toLowerCase()) === symbolMatch[0]) {
        return exactMatches.push(token);
      } else if ((_token$symbol2 = token.symbol) !== null && _token$symbol2 !== void 0 && _token$symbol2.toLowerCase().startsWith(searchQuery.toLowerCase().trim())) {
        return symbolSubtrings.push(token);
      } else {
        return rest.push(token);
      }
    });
    return [...exactMatches, ...symbolSubtrings, ...rest];
  }, [tokens, searchQuery]);
}

/***/ }),

/***/ 6269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e_": () => (/* binding */ useAllTokens),
/* harmony export */   "l6": () => (/* binding */ useUnsupportedTokens),
/* harmony export */   "S5": () => (/* binding */ useSearchInactiveTokenLists),
/* harmony export */   "ZN": () => (/* binding */ useIsTokenActive),
/* harmony export */   "EH": () => (/* binding */ useIsUserAddedToken),
/* harmony export */   "dQ": () => (/* binding */ useToken),
/* harmony export */   "U8": () => (/* binding */ useCurrency)
/* harmony export */ });
/* unused harmony export useTokens */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(879);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(780);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6435);
/* harmony import */ var _state_lists_wrappedTokenInfo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2045);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4103);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bytes__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _functions_filtering__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5899);
/* harmony import */ var _functions_validate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2556);
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8890);
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_strings__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8269);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(181);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













 // reduce token map into standard address <-> Token mapping, optionally include user added tokens

function useTokensFromMap(tokenMap, includeUserAdded) {
  const {
    chainId
  } = (0,_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__/* .useActiveWeb3React */ .a)();
  const userAddedTokens = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useUserAddedTokens */ .em)();
  return (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(() => {
    if (!chainId) return {}; // reduce to just tokens

    const mapWithoutUrls = Object.keys(tokenMap[chainId]).reduce((newMap, address) => {
      newMap[address] = tokenMap[chainId][address].token;
      return newMap;
    }, {});

    if (includeUserAdded) {
      return userAddedTokens // reduce into all ALL_TOKENS filtered by the current chain
      .reduce((tokenMap, token) => {
        tokenMap[token.address] = token;
        return tokenMap;
      }, // must make a copy because reduce modifies the map, and we do not
      // want to make a copy in every iteration
      _objectSpread({}, mapWithoutUrls));
    }

    return mapWithoutUrls;
  }, [chainId, userAddedTokens, tokenMap, includeUserAdded]);
}

function useAllTokens() {
  const allTokens = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useCombinedActiveList */ .z0)();
  return useTokensFromMap(allTokens, true);
}
function useTokens() {
  const allTokens = useCombinedActiveList();
  return useTokensFromMap(allTokens, false);
}
function useUnsupportedTokens() {
  const unsupportedTokensMap = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useUnsupportedTokenList */ .Rx)();
  return useTokensFromMap(unsupportedTokensMap, false);
}
function useSearchInactiveTokenLists(search, minResults = 10) {
  const lists = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAllLists */ .R0)();
  const inactiveUrls = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useInactiveListUrls */ .eu)();
  const {
    chainId
  } = (0,_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__/* .useActiveWeb3React */ .a)();
  const activeTokens = useAllTokens();
  return (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(() => {
    if (!search || search.trim().length === 0) return [];
    const tokenFilter = (0,_functions_filtering__WEBPACK_IMPORTED_MODULE_6__/* .createTokenFilterFunction */ .Ki)(search);
    const result = [];
    const addressSet = {};

    for (const url of inactiveUrls) {
      const list = lists[url].current;
      if (!list) continue;

      for (const tokenInfo of list.tokens) {
        if (tokenInfo.chainId === chainId && tokenFilter(tokenInfo)) {
          const wrapped = new _state_lists_wrappedTokenInfo__WEBPACK_IMPORTED_MODULE_4__/* .WrappedTokenInfo */ .D(tokenInfo, list);

          if (!(wrapped.address in activeTokens) && !addressSet[wrapped.address]) {
            addressSet[wrapped.address] = true;
            result.push(wrapped);
            if (result.length >= minResults) return result;
          }
        }
      }
    }

    return result;
  }, [activeTokens, chainId, inactiveUrls, lists, minResults, search]);
}
function useIsTokenActive(token) {
  const activeTokens = useAllTokens();

  if (!activeTokens || !token) {
    return false;
  }

  return !!activeTokens[token.address];
} // Check if currency is included in custom list from user storage

function useIsUserAddedToken(currency) {
  const userAddedTokens = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useUserAddedTokens */ .em)();

  if (!currency) {
    return false;
  }

  return !!userAddedTokens.find(token => currency.equals(token));
} // parse a name or symbol from a token response

const BYTES32_REGEX = /^0x[a-fA-F0-9]{64}$/;

function parseStringOrBytes32(str, bytes32, defaultValue) {
  return str && str.length > 0 ? str : // need to check for proper bytes string and valid terminator
  bytes32 && BYTES32_REGEX.test(bytes32) && (0,_ethersproject_bytes__WEBPACK_IMPORTED_MODULE_5__.arrayify)(bytes32)[31] === 0 ? (0,_ethersproject_strings__WEBPACK_IMPORTED_MODULE_8__.parseBytes32String)(bytes32) : defaultValue;
} // undefined if invalid or does not exist
// null if loading
// otherwise returns the token


function useToken(tokenAddress) {
  const {
    chainId
  } = (0,_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__/* .useActiveWeb3React */ .a)();
  const tokens = useAllTokens();
  const address = (0,_functions_validate__WEBPACK_IMPORTED_MODULE_7__/* .isAddress */ .UJ)(tokenAddress);
  const tokenContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useTokenContract */ .Ib)(address ? address : undefined, false);
  const tokenContractBytes32 = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useBytes32TokenContract */ .gs)(address ? address : undefined, false);
  const token = address ? tokens[address] : undefined;
  const tokenName = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContract, 'name', undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .NEVER_RELOAD */ .DB);
  const tokenNameBytes32 = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContractBytes32, 'name', undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .NEVER_RELOAD */ .DB);
  const symbol = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContract, 'symbol', undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .NEVER_RELOAD */ .DB);
  const symbolBytes32 = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContractBytes32, 'symbol', undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .NEVER_RELOAD */ .DB);
  const decimals = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContract, 'decimals', undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .NEVER_RELOAD */ .DB);
  return (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(() => {
    if (token) return token;
    if (!chainId || !address) return undefined;
    if (decimals.loading || symbol.loading || tokenName.loading) return null;

    if (decimals.result) {
      var _symbol$result, _symbolBytes32$result, _tokenName$result, _tokenNameBytes32$res;

      return new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(chainId, address, decimals.result[0], parseStringOrBytes32((_symbol$result = symbol.result) === null || _symbol$result === void 0 ? void 0 : _symbol$result[0], (_symbolBytes32$result = symbolBytes32.result) === null || _symbolBytes32$result === void 0 ? void 0 : _symbolBytes32$result[0], 'UNKNOWN'), parseStringOrBytes32((_tokenName$result = tokenName.result) === null || _tokenName$result === void 0 ? void 0 : _tokenName$result[0], (_tokenNameBytes32$res = tokenNameBytes32.result) === null || _tokenNameBytes32$res === void 0 ? void 0 : _tokenNameBytes32$res[0], 'Unknown Token'));
    }

    return undefined;
  }, [address, chainId, decimals.loading, decimals.result, symbol.loading, symbol.result, symbolBytes32.result, token, tokenName.loading, tokenName.result, tokenNameBytes32.result]);
}
function useCurrency(currencyId) {
  var _currencyId, _wnative$address, _currencyId2;

  const {
    chainId
  } = (0,_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__/* .useActiveWeb3React */ .a)();
  const isETH = ((_currencyId = currencyId) === null || _currencyId === void 0 ? void 0 : _currencyId.toUpperCase()) === 'ETH';
  const isDual = [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO].includes(chainId);
  const useNative = isETH && !isDual;

  if (isETH && isDual) {
    currencyId = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.WNATIVE_ADDRESS[chainId];
  }

  const token = useToken(useNative ? undefined : currencyId); // const extendedEther = useMemo(() => (chainId ? ExtendedEther.onChain(chainId) : undefined), [chainId])
  // const weth = chainId ? WETH9_EXTENDED[chainId] : undefined

  const native = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(() => chainId ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.NATIVE[chainId] : undefined, [chainId]);
  const wnative = chainId ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.WNATIVE[chainId] : undefined;
  if ((wnative === null || wnative === void 0 ? void 0 : (_wnative$address = wnative.address) === null || _wnative$address === void 0 ? void 0 : _wnative$address.toLowerCase()) === ((_currencyId2 = currencyId) === null || _currencyId2 === void 0 ? void 0 : _currencyId2.toLowerCase())) return wnative;
  return useNative ? native : token;
}

/***/ }),

/***/ 8269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useActiveWeb3React),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8532);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(417);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function useActiveWeb3React() {
  // replace with address to impersonate
  const impersonate = false;
  const context = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
  const contextNetwork = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)(_constants__WEBPACK_IMPORTED_MODULE_1__/* .NetworkContextName */ .AQ);
  return context.active ? _objectSpread(_objectSpread({}, context), {}, {
    account: impersonate || context.account
  }) : _objectSpread(_objectSpread({}, contextNetwork), {}, {
    account: impersonate || contextNetwork.account,
    chainId: _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC
  });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useActiveWeb3React);

/***/ }),

/***/ 6435:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "c5": () => (/* binding */ useArgentWalletDetectorContract),
  "rO": () => (/* binding */ useBentoBoxContract),
  "HW": () => (/* binding */ useBoringHelperContract),
  "gs": () => (/* binding */ useBytes32TokenContract),
  "eH": () => (/* binding */ useCloneRewarderContract),
  "fQ": () => (/* binding */ useComplexRewarderContract),
  "cq": () => (/* binding */ useContract),
  "N9": () => (/* binding */ useEIP2612Contract),
  "zb": () => (/* binding */ useENSRegistrarContract),
  "uU": () => (/* binding */ useENSResolverContract),
  "MQ": () => (/* binding */ useFactoryContract),
  "ax": () => (/* binding */ useLICPContract),
  "JY": () => (/* binding */ useLimitOrderContract),
  "wq": () => (/* binding */ useLimitOrderHelperContract),
  "mi": () => (/* binding */ useMasterChefContract),
  "sd": () => (/* binding */ useMasterChefV2Contract),
  "JD": () => (/* binding */ useMeowshiContract),
  "U$": () => (/* binding */ useMiniChefContract),
  "Fe": () => (/* binding */ useMulticall2Contract),
  "t0": () => (/* binding */ usePairContract),
  "Ti": () => (/* binding */ useRouterContract),
  "Vu": () => (/* binding */ useSushiBarContract),
  "Z9": () => (/* binding */ useSushiContract),
  "Ib": () => (/* binding */ useTokenContract),
  "lz": () => (/* binding */ useWETH9Contract)
});

// UNUSED EXPORTS: useChainlinkOracle, useInariContract, useMakerContract, useMerkleDistributorContract, useTimelockContract, useUniV2FactoryContract, useZenkoContract

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
;// CONCATENATED MODULE: ./src/constants/abis/argent-wallet-detector.json
const argent_wallet_detector_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"bytes32[]","name":"_codes","type":"bytes32[]"},{"internalType":"address[]","name":"_implementations","type":"address[]"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"code","type":"bytes32"}],"name":"CodeAdded","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"implementation","type":"address"}],"name":"ImplementationAdded","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"_newOwner","type":"address"}],"name":"OwnerChanged","type":"event"},{"inputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"name":"acceptedCodes","outputs":[{"internalType":"bool","name":"exists","type":"bool"},{"internalType":"uint128","name":"index","type":"uint128"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"acceptedImplementations","outputs":[{"internalType":"bool","name":"exists","type":"bool"},{"internalType":"uint128","name":"index","type":"uint128"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"_code","type":"bytes32"}],"name":"addCode","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_argentWallet","type":"address"}],"name":"addCodeAndImplementationFromWallet","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_impl","type":"address"}],"name":"addImplementation","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_newOwner","type":"address"}],"name":"changeOwner","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getCodes","outputs":[{"internalType":"bytes32[]","name":"","type":"bytes32[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getImplementations","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_wallet","type":"address"}],"name":"isArgentWallet","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/argent-wallet-detector.ts

const ARGENT_WALLET_DETECTOR_MAINNET_ADDRESS = '0xeca4B0bDBf7c55E9b7925919d03CbF8Dc82537E8';

// EXTERNAL MODULE: ./src/constants/abis/archer-router.json
var archer_router = __webpack_require__(9233);
;// CONCATENATED MODULE: ./src/constants/abis/bar.json
const bar_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IERC20","name":"_stakedToken","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"enter","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_share","type":"uint256"}],"name":"leave","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"stakedToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"userInfo","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"rewardDebt","type":"uint256"},{"internalType":"uint256","name":"unlockTime","type":"uint256"}],"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/bentobox.json
const bentobox_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IERC20","name":"wethToken_","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"masterContract","type":"address"},{"indexed":false,"internalType":"bytes","name":"data","type":"bytes"},{"indexed":true,"internalType":"address","name":"cloneAddress","type":"address"}],"name":"LogDeploy","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"share","type":"uint256"}],"name":"LogDeposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"borrower","type":"address"},{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"feeAmount","type":"uint256"},{"indexed":true,"internalType":"address","name":"receiver","type":"address"}],"name":"LogFlashLoan","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"protocol","type":"address"}],"name":"LogRegisterProtocol","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"masterContract","type":"address"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"LogSetMasterContractApproval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"LogStrategyDivest","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"LogStrategyInvest","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"LogStrategyLoss","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"LogStrategyProfit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":true,"internalType":"contract IStrategy","name":"strategy","type":"address"}],"name":"LogStrategyQueued","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":true,"internalType":"contract IStrategy","name":"strategy","type":"address"}],"name":"LogStrategySet","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"targetPercentage","type":"uint256"}],"name":"LogStrategyTargetPercentage","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"share","type":"uint256"}],"name":"LogTransfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"masterContract","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"LogWhiteListMasterContract","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"share","type":"uint256"}],"name":"LogWithdraw","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes[]","name":"calls","type":"bytes[]"},{"internalType":"bool","name":"revertOnFail","type":"bool"}],"name":"batch","outputs":[{"internalType":"bool[]","name":"successes","type":"bool[]"},{"internalType":"bytes[]","name":"results","type":"bytes[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"contract IBatchFlashBorrower","name":"borrower","type":"address"},{"internalType":"address[]","name":"receivers","type":"address[]"},{"internalType":"contract IERC20[]","name":"tokens","type":"address[]"},{"internalType":"uint256[]","name":"amounts","type":"uint256[]"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"batchFlashLoan","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"claimOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"masterContract","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"},{"internalType":"bool","name":"useCreate2","type":"bool"}],"name":"deploy","outputs":[{"internalType":"address","name":"cloneAddress","type":"address"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token_","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"share","type":"uint256"}],"name":"deposit","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"shareOut","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"contract IFlashBorrower","name":"borrower","type":"address"},{"internalType":"address","name":"receiver","type":"address"},{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"flashLoan","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"bool","name":"balance","type":"bool"},{"internalType":"uint256","name":"maxChangeAmount","type":"uint256"}],"name":"harvest","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"masterContractApproved","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"masterContractOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pendingOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"name":"pendingStrategy","outputs":[{"internalType":"contract IStrategy","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permitToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"registerProtocol","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"},{"internalType":"address","name":"masterContract","type":"address"},{"internalType":"bool","name":"approved","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"setMasterContractApproval","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"contract IStrategy","name":"newStrategy","type":"address"}],"name":"setStrategy","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint64","name":"targetPercentage_","type":"uint64"}],"name":"setStrategyTargetPercentage","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"name":"strategy","outputs":[{"internalType":"contract IStrategy","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"name":"strategyData","outputs":[{"internalType":"uint64","name":"strategyStartDate","type":"uint64"},{"internalType":"uint64","name":"targetPercentage","type":"uint64"},{"internalType":"uint128","name":"balance","type":"uint128"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint256","name":"share","type":"uint256"},{"internalType":"bool","name":"roundUp","type":"bool"}],"name":"toAmount","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"bool","name":"roundUp","type":"bool"}],"name":"toShare","outputs":[{"internalType":"uint256","name":"share","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"name":"totals","outputs":[{"internalType":"uint128","name":"elastic","type":"uint128"},{"internalType":"uint128","name":"base","type":"uint128"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"share","type":"uint256"}],"name":"transfer","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address[]","name":"tos","type":"address[]"},{"internalType":"uint256[]","name":"shares","type":"uint256[]"}],"name":"transferMultiple","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"},{"internalType":"bool","name":"direct","type":"bool"},{"internalType":"bool","name":"renounce","type":"bool"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"masterContract","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"whitelistMasterContract","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"whitelistedMasterContracts","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token_","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"share","type":"uint256"}],"name":"withdraw","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"shareOut","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]');
;// CONCATENATED MODULE: ./src/constants/abis/boring-helper.json
const boring_helper_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IMasterChef","name":"chef_","type":"address"},{"internalType":"address","name":"maker_","type":"address"},{"internalType":"contract IERC20","name":"sushi_","type":"address"},{"internalType":"contract IERC20","name":"WETH_","type":"address"},{"internalType":"contract IERC20","name":"WBTC_","type":"address"},{"internalType":"contract IFactory","name":"sushiFactory_","type":"address"},{"internalType":"contract IFactory","name":"uniV2Factory_","type":"address"},{"internalType":"contract IERC20","name":"bar_","type":"address"},{"internalType":"contract IBentoBox","name":"bentoBox_","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"WBTC","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"WETH","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"bar","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"bentoBox","outputs":[{"internalType":"contract IBentoBox","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"chef","outputs":[{"internalType":"contract IMasterChef","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"address[]","name":"addresses","type":"address[]"}],"name":"findBalances","outputs":[{"components":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint256","name":"balance","type":"uint256"},{"internalType":"uint256","name":"bentoBalance","type":"uint256"}],"internalType":"struct BoringHelperV1.Balance[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"uint256[]","name":"pids","type":"uint256[]"}],"name":"findPools","outputs":[{"components":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"balance","type":"uint256"}],"internalType":"struct BoringHelperV1.PoolFound[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"contract IERC20[]","name":"addresses","type":"address[]"}],"name":"getBalances","outputs":[{"components":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint256","name":"totalSupply","type":"uint256"},{"internalType":"uint256","name":"balance","type":"uint256"},{"internalType":"uint256","name":"bentoBalance","type":"uint256"},{"internalType":"uint256","name":"bentoAllowance","type":"uint256"},{"internalType":"uint256","name":"nonce","type":"uint256"},{"internalType":"uint128","name":"bentoAmount","type":"uint128"},{"internalType":"uint128","name":"bentoShare","type":"uint128"},{"internalType":"uint256","name":"rate","type":"uint256"}],"internalType":"struct BoringHelperV1.BalanceFull[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"}],"name":"getETHRate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IFactory","name":"factory","type":"address"},{"internalType":"uint256","name":"fromID","type":"uint256"},{"internalType":"uint256","name":"toID","type":"uint256"}],"name":"getPairs","outputs":[{"components":[{"internalType":"contract IPair","name":"token","type":"address"},{"internalType":"contract IERC20","name":"token0","type":"address"},{"internalType":"contract IERC20","name":"token1","type":"address"},{"internalType":"uint256","name":"totalSupply","type":"uint256"}],"internalType":"struct BoringHelperV1.PairBase[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"pids","type":"uint256[]"}],"name":"getPools","outputs":[{"components":[{"internalType":"uint256","name":"totalAllocPoint","type":"uint256"},{"internalType":"uint256","name":"poolLength","type":"uint256"}],"internalType":"struct BoringHelperV1.PoolsInfo","name":"","type":"tuple"},{"components":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"contract IPair","name":"lpToken","type":"address"},{"internalType":"uint256","name":"allocPoint","type":"uint256"},{"internalType":"bool","name":"isPair","type":"bool"},{"internalType":"contract IFactory","name":"factory","type":"address"},{"internalType":"contract IERC20","name":"token0","type":"address"},{"internalType":"contract IERC20","name":"token1","type":"address"},{"internalType":"string","name":"name","type":"string"},{"internalType":"string","name":"symbol","type":"string"},{"internalType":"uint8","name":"decimals","type":"uint8"}],"internalType":"struct BoringHelperV1.PoolInfo[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address[]","name":"addresses","type":"address[]"}],"name":"getTokenInfo","outputs":[{"components":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"uint256","name":"decimals","type":"uint256"},{"internalType":"string","name":"name","type":"string"},{"internalType":"string","name":"symbol","type":"string"},{"internalType":"bytes32","name":"DOMAIN_SEPARATOR","type":"bytes32"}],"internalType":"struct BoringHelperV1.TokenInfo[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"contract IFactory[]","name":"factoryAddresses","type":"address[]"},{"internalType":"contract IERC20","name":"currency","type":"address"},{"internalType":"address[]","name":"masterContracts","type":"address[]"}],"name":"getUIInfo","outputs":[{"components":[{"internalType":"uint256","name":"ethBalance","type":"uint256"},{"internalType":"uint256","name":"sushiBalance","type":"uint256"},{"internalType":"uint256","name":"sushiBarBalance","type":"uint256"},{"internalType":"uint256","name":"xsushiBalance","type":"uint256"},{"internalType":"uint256","name":"xsushiSupply","type":"uint256"},{"internalType":"uint256","name":"sushiBarAllowance","type":"uint256"},{"components":[{"internalType":"contract IFactory","name":"factory","type":"address"},{"internalType":"uint256","name":"allPairsLength","type":"uint256"}],"internalType":"struct BoringHelperV1.Factory[]","name":"factories","type":"tuple[]"},{"internalType":"uint256","name":"ethRate","type":"uint256"},{"internalType":"uint256","name":"sushiRate","type":"uint256"},{"internalType":"uint256","name":"btcRate","type":"uint256"},{"internalType":"uint256","name":"pendingSushi","type":"uint256"},{"internalType":"uint256","name":"blockTimeStamp","type":"uint256"},{"internalType":"bool[]","name":"masterContractApproved","type":"bool[]"}],"internalType":"struct BoringHelperV1.UIInfo","name":"","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"maker","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"contract IKashiPair[]","name":"pairsIn","type":"address[]"}],"name":"pollKashiPairs","outputs":[{"components":[{"internalType":"contract IERC20","name":"collateral","type":"address"},{"internalType":"contract IERC20","name":"asset","type":"address"},{"internalType":"contract IOracle","name":"oracle","type":"address"},{"internalType":"bytes","name":"oracleData","type":"bytes"},{"internalType":"uint256","name":"totalCollateralShare","type":"uint256"},{"internalType":"uint256","name":"userCollateralShare","type":"uint256"},{"components":[{"internalType":"uint128","name":"elastic","type":"uint128"},{"internalType":"uint128","name":"base","type":"uint128"}],"internalType":"struct Rebase","name":"totalAsset","type":"tuple"},{"internalType":"uint256","name":"userAssetFraction","type":"uint256"},{"components":[{"internalType":"uint128","name":"elastic","type":"uint128"},{"internalType":"uint128","name":"base","type":"uint128"}],"internalType":"struct Rebase","name":"totalBorrow","type":"tuple"},{"internalType":"uint256","name":"userBorrowPart","type":"uint256"},{"internalType":"uint256","name":"currentExchangeRate","type":"uint256"},{"internalType":"uint256","name":"spotExchangeRate","type":"uint256"},{"internalType":"uint256","name":"oracleExchangeRate","type":"uint256"},{"components":[{"internalType":"uint64","name":"interestPerSecond","type":"uint64"},{"internalType":"uint64","name":"lastAccrued","type":"uint64"},{"internalType":"uint128","name":"feesEarnedFraction","type":"uint128"}],"internalType":"struct AccrueInfo","name":"accrueInfo","type":"tuple"}],"internalType":"struct BoringHelperV1.KashiPairPoll[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"contract IPair[]","name":"addresses","type":"address[]"}],"name":"pollPairs","outputs":[{"components":[{"internalType":"contract IPair","name":"token","type":"address"},{"internalType":"uint256","name":"reserve0","type":"uint256"},{"internalType":"uint256","name":"reserve1","type":"uint256"},{"internalType":"uint256","name":"totalSupply","type":"uint256"},{"internalType":"uint256","name":"balance","type":"uint256"}],"internalType":"struct BoringHelperV1.PairPoll[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"uint256[]","name":"pids","type":"uint256[]"}],"name":"pollPools","outputs":[{"components":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"balance","type":"uint256"},{"internalType":"uint256","name":"totalSupply","type":"uint256"},{"internalType":"uint256","name":"lpBalance","type":"uint256"},{"internalType":"uint256","name":"lpTotalSupply","type":"uint256"},{"internalType":"uint256","name":"lpAllowance","type":"uint256"},{"internalType":"uint256","name":"reserve0","type":"uint256"},{"internalType":"uint256","name":"reserve1","type":"uint256"},{"internalType":"uint256","name":"rewardDebt","type":"uint256"},{"internalType":"uint256","name":"pending","type":"uint256"}],"internalType":"struct BoringHelperV1.UserPoolInfo[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IMasterChef","name":"chef_","type":"address"},{"internalType":"address","name":"maker_","type":"address"},{"internalType":"contract IERC20","name":"sushi_","type":"address"},{"internalType":"contract IERC20","name":"WETH_","type":"address"},{"internalType":"contract IERC20","name":"WBTC_","type":"address"},{"internalType":"contract IFactory","name":"sushiFactory_","type":"address"},{"internalType":"contract IFactory","name":"uniV2Factory_","type":"address"},{"internalType":"contract IERC20","name":"bar_","type":"address"},{"internalType":"contract IBentoBox","name":"bentoBox_","type":"address"}],"name":"setContracts","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"sushi","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"sushiFactory","outputs":[{"internalType":"contract IFactory","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"uniV2Factory","outputs":[{"internalType":"contract IFactory","name":"","type":"address"}],"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/chainlink-oracle.json
const chainlink_oracle_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/clone-rewarder.json
const clone_rewarder_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"address","name":"_MASTERCHEF_V2","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"rewardToken","type":"address"},{"indexed":false,"internalType":"address","name":"owner","type":"address"},{"indexed":false,"internalType":"uint256","name":"rewardPerSecond","type":"uint256"},{"indexed":true,"internalType":"contract IERC20","name":"masterLpToken","type":"address"}],"name":"LogInit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"LogOnReward","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"allocPoint","type":"uint256"}],"name":"LogPoolAddition","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"rewardPerSecond","type":"uint256"}],"name":"LogRewardPerSecond","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"allocPoint","type":"uint256"}],"name":"LogSetPool","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint64","name":"lastRewardTime","type":"uint64"},{"indexed":false,"internalType":"uint256","name":"lpSupply","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"accToken1PerShare","type":"uint256"}],"name":"LogUpdatePool","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"inputs":[],"name":"MASTERCHEF_V2","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"claimOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes","name":"data","type":"bytes"}],"name":"init","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"masterLpToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"address","name":"_user","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"lpTokenAmount","type":"uint256"}],"name":"onSushiReward","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pendingOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"address","name":"_user","type":"address"}],"name":"pendingToken","outputs":[{"internalType":"uint256","name":"pending","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"address","name":"user","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"pendingTokens","outputs":[{"internalType":"contract IERC20[]","name":"rewardTokens","type":"address[]"},{"internalType":"uint256[]","name":"rewardAmounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"poolInfo","outputs":[{"internalType":"uint128","name":"accToken1PerShare","type":"uint128"},{"internalType":"uint64","name":"lastRewardTime","type":"uint64"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardPerSecond","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardRates","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_rewardPerSecond","type":"uint256"}],"name":"setRewardPerSecond","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"},{"internalType":"bool","name":"direct","type":"bool"},{"internalType":"bool","name":"renounce","type":"bool"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"}],"name":"updatePool","outputs":[{"components":[{"internalType":"uint128","name":"accToken1PerShare","type":"uint128"},{"internalType":"uint64","name":"lastRewardTime","type":"uint64"}],"internalType":"struct PickleRewarder.PoolInfo","name":"pool","type":"tuple"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"userInfo","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"rewardDebt","type":"uint256"}],"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/complex-rewarder.json
const complex_rewarder_namespaceObject = JSON.parse('[{"type":"constructor","stateMutability":"nonpayable","inputs":[{"type":"address","name":"_rewardToken","internalType":"contract IERC20"},{"type":"uint256","name":"_rewardPerSecond","internalType":"uint256"},{"type":"address","name":"_MASTERCHEF_V2","internalType":"address"}]},{"type":"event","name":"LogInit","inputs":[],"anonymous":false},{"type":"event","name":"LogOnReward","inputs":[{"type":"address","name":"user","internalType":"address","indexed":true},{"type":"uint256","name":"pid","internalType":"uint256","indexed":true},{"type":"uint256","name":"amount","internalType":"uint256","indexed":false},{"type":"address","name":"to","internalType":"address","indexed":true}],"anonymous":false},{"type":"event","name":"LogPoolAddition","inputs":[{"type":"uint256","name":"pid","internalType":"uint256","indexed":true},{"type":"uint256","name":"allocPoint","internalType":"uint256","indexed":false}],"anonymous":false},{"type":"event","name":"LogRewardPerSecond","inputs":[{"type":"uint256","name":"rewardPerSecond","internalType":"uint256","indexed":false}],"anonymous":false},{"type":"event","name":"LogSetPool","inputs":[{"type":"uint256","name":"pid","internalType":"uint256","indexed":true},{"type":"uint256","name":"allocPoint","internalType":"uint256","indexed":false}],"anonymous":false},{"type":"event","name":"LogUpdatePool","inputs":[{"type":"uint256","name":"pid","internalType":"uint256","indexed":true},{"type":"uint64","name":"lastRewardTime","internalType":"uint64","indexed":false},{"type":"uint256","name":"lpSupply","internalType":"uint256","indexed":false},{"type":"uint256","name":"accSushiPerShare","internalType":"uint256","indexed":false}],"anonymous":false},{"type":"event","name":"OwnershipTransferred","inputs":[{"type":"address","name":"previousOwner","internalType":"address","indexed":true},{"type":"address","name":"newOwner","internalType":"address","indexed":true}],"anonymous":false},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"add","inputs":[{"type":"uint256","name":"allocPoint","internalType":"uint256"},{"type":"uint256","name":"_pid","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"claimOwnership","inputs":[]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"massUpdatePools","inputs":[{"type":"uint256[]","name":"pids","internalType":"uint256[]"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"onSushiReward","inputs":[{"type":"uint256","name":"pid","internalType":"uint256"},{"type":"address","name":"_user","internalType":"address"},{"type":"address","name":"to","internalType":"address"},{"type":"uint256","name":"","internalType":"uint256"},{"type":"uint256","name":"lpToken","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"address","name":"","internalType":"address"}],"name":"owner","inputs":[]},{"type":"function","stateMutability":"view","outputs":[{"type":"address","name":"","internalType":"address"}],"name":"pendingOwner","inputs":[]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"pending","internalType":"uint256"}],"name":"pendingToken","inputs":[{"type":"uint256","name":"_pid","internalType":"uint256"},{"type":"address","name":"_user","internalType":"address"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"address[]","name":"rewardTokens","internalType":"contract IERC20[]"},{"type":"uint256[]","name":"rewardAmounts","internalType":"uint256[]"}],"name":"pendingTokens","inputs":[{"type":"uint256","name":"pid","internalType":"uint256"},{"type":"address","name":"user","internalType":"address"},{"type":"uint256","name":"","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"","internalType":"uint256"}],"name":"poolIds","inputs":[{"type":"uint256","name":"","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint128","name":"accSushiPerShare","internalType":"uint128"},{"type":"uint64","name":"lastRewardTime","internalType":"uint64"},{"type":"uint64","name":"allocPoint","internalType":"uint64"}],"name":"poolInfo","inputs":[{"type":"uint256","name":"","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"pools","internalType":"uint256"}],"name":"poolLength","inputs":[]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"","internalType":"uint256"}],"name":"rewardPerSecond","inputs":[]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"set","inputs":[{"type":"uint256","name":"_pid","internalType":"uint256"},{"type":"uint256","name":"_allocPoint","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"setRewardPerSecond","inputs":[{"type":"uint256","name":"_rewardPerSecond","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"transferOwnership","inputs":[{"type":"address","name":"newOwner","internalType":"address"},{"type":"bool","name":"direct","internalType":"bool"},{"type":"bool","name":"renounce","internalType":"bool"}]},{"type":"function","stateMutability":"nonpayable","outputs":[{"type":"tuple","name":"pool","internalType":"struct ComplexRewarderTime.PoolInfo","components":[{"type":"uint128","name":"accSushiPerShare","internalType":"uint128"},{"type":"uint64","name":"lastRewardTime","internalType":"uint64"},{"type":"uint64","name":"allocPoint","internalType":"uint64"}]}],"name":"updatePool","inputs":[{"type":"uint256","name":"pid","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"amount","internalType":"uint256"},{"type":"uint256","name":"rewardDebt","internalType":"uint256"}],"name":"userInfo","inputs":[{"type":"uint256","name":"","internalType":"uint256"},{"type":"address","name":"","internalType":"address"}]}]');
;// CONCATENATED MODULE: ./src/constants/abis/eip-2612.json
const eip_2612_namespaceObject = JSON.parse('[{"constant":true,"inputs":[{"name":"owner","type":"address"}],"name":"nonces","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/ens-registrar.json
const ens_registrar_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract ENS","name":"_old","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"label","type":"bytes32"},{"indexed":false,"internalType":"address","name":"owner","type":"address"}],"name":"NewOwner","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"address","name":"resolver","type":"address"}],"name":"NewResolver","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"NewTTL","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"address","name":"owner","type":"address"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"old","outputs":[{"internalType":"contract ENS","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"recordExists","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"resolver","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"}],"name":"setOwner","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"resolver","type":"address"},{"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"setRecord","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"resolver","type":"address"}],"name":"setResolver","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"label","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"}],"name":"setSubnodeOwner","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"label","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"resolver","type":"address"},{"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"setSubnodeRecord","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"setTTL","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"ttl","outputs":[{"internalType":"uint64","name":"","type":"uint64"}],"payable":false,"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/ens-public-resolver.json
const ens_public_resolver_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract ENS","name":"_ens","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"uint256","name":"contentType","type":"uint256"}],"name":"ABIChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"address","name":"a","type":"address"}],"name":"AddrChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"uint256","name":"coinType","type":"uint256"},{"indexed":false,"internalType":"bytes","name":"newAddress","type":"bytes"}],"name":"AddressChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"target","type":"address"},{"indexed":false,"internalType":"bool","name":"isAuthorised","type":"bool"}],"name":"AuthorisationChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"hash","type":"bytes"}],"name":"ContenthashChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"name","type":"bytes"},{"indexed":false,"internalType":"uint16","name":"resource","type":"uint16"},{"indexed":false,"internalType":"bytes","name":"record","type":"bytes"}],"name":"DNSRecordChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"name","type":"bytes"},{"indexed":false,"internalType":"uint16","name":"resource","type":"uint16"}],"name":"DNSRecordDeleted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"DNSZoneCleared","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"bytes4","name":"interfaceID","type":"bytes4"},{"indexed":false,"internalType":"address","name":"implementer","type":"address"}],"name":"InterfaceChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"string","name":"name","type":"string"}],"name":"NameChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes32","name":"x","type":"bytes32"},{"indexed":false,"internalType":"bytes32","name":"y","type":"bytes32"}],"name":"PubkeyChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"string","name":"indexedKey","type":"string"},{"indexed":false,"internalType":"string","name":"key","type":"string"}],"name":"TextChanged","type":"event"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint256","name":"contentTypes","type":"uint256"}],"name":"ABI","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"bytes","name":"","type":"bytes"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"addr","outputs":[{"internalType":"address payable","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"","type":"bytes32"},{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"authorisations","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"clearDNSZone","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"contenthash","outputs":[{"internalType":"bytes","name":"","type":"bytes"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"name","type":"bytes32"},{"internalType":"uint16","name":"resource","type":"uint16"}],"name":"dnsRecord","outputs":[{"internalType":"bytes","name":"","type":"bytes"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"name","type":"bytes32"}],"name":"hasDNSRecords","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes4","name":"interfaceID","type":"bytes4"}],"name":"interfaceImplementer","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"pubkey","outputs":[{"internalType":"bytes32","name":"x","type":"bytes32"},{"internalType":"bytes32","name":"y","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint256","name":"contentType","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"setABI","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint256","name":"coinType","type":"uint256"},{"internalType":"bytes","name":"a","type":"bytes"}],"name":"setAddr","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"a","type":"address"}],"name":"setAddr","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"target","type":"address"},{"internalType":"bool","name":"isAuthorised","type":"bool"}],"name":"setAuthorisation","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes","name":"hash","type":"bytes"}],"name":"setContenthash","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"setDNSRecords","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes4","name":"interfaceID","type":"bytes4"},{"internalType":"address","name":"implementer","type":"address"}],"name":"setInterface","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"string","name":"name","type":"string"}],"name":"setName","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"x","type":"bytes32"},{"internalType":"bytes32","name":"y","type":"bytes32"}],"name":"setPubkey","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"string","name":"key","type":"string"},{"internalType":"string","name":"value","type":"string"}],"name":"setText","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes4","name":"interfaceID","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"string","name":"key","type":"string"}],"name":"text","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"}]');
// EXTERNAL MODULE: ./src/constants/abis/erc20.json
var erc20 = __webpack_require__(9638);
// EXTERNAL MODULE: external "@ethersproject/abi"
var abi_ = __webpack_require__(6124);
;// CONCATENATED MODULE: ./src/constants/abis/erc20_bytes32.json
const erc20_bytes32_namespaceObject = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/erc20.ts



const ERC20_INTERFACE = new abi_.Interface(erc20);
const ERC20_BYTES32_INTERFACE = new abi_.Interface(erc20_bytes32_namespaceObject);
/* harmony default export */ const abis_erc20 = ((/* unused pure expression or super */ null && (ERC20_INTERFACE)));

;// CONCATENATED MODULE: ./src/constants/abis/factory.json
const factory_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"address","name":"_feeToSetter","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"token0","type":"address"},{"indexed":true,"internalType":"address","name":"token1","type":"address"},{"indexed":false,"internalType":"address","name":"pair","type":"address"},{"indexed":false,"internalType":"uint256","name":"","type":"uint256"}],"name":"PairCreated","type":"event"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"allPairs","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"allPairsLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"}],"name":"createPair","outputs":[{"internalType":"address","name":"pair","type":"address"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"feeTo","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeToSetter","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"getPair","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"migrator","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pairCodeHash","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"_feeTo","type":"address"}],"name":"setFeeTo","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_feeToSetter","type":"address"}],"name":"setFeeToSetter","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_migrator","type":"address"}],"name":"setMigrator","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/inari.json
const inari_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/uniswap-v2-pair.json
const uniswap_v2_pair_namespaceObject = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount0Out","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1Out","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Swap","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint112","name":"reserve0","type":"uint112"},{"indexed":false,"internalType":"uint112","name":"reserve1","type":"uint112"}],"name":"Sync","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"MINIMUM_LIQUIDITY","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":true,"inputs":[],"name":"PERMIT_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"burn","outputs":[{"internalType":"uint256","name":"amount0","type":"uint256"},{"internalType":"uint256","name":"amount1","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":true,"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getReserves","outputs":[{"internalType":"uint112","name":"reserve0","type":"uint112"},{"internalType":"uint112","name":"reserve1","type":"uint112"},{"internalType":"uint32","name":"blockTimestampLast","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"initialize","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"kLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"mint","outputs":[{"internalType":"uint256","name":"liquidity","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permit","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"price0CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"price1CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"skim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"uint256","name":"amount0Out","type":"uint256"},{"internalType":"uint256","name":"amount1Out","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"swap","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":false,"inputs":[],"name":"sync","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"token0","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"token1","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/limit-order.json
const limit_order_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"uint256","name":"_externalOrderFee","type":"uint256"},{"internalType":"contract IBentoBoxV1","name":"_bentoBox","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract IERC20","name":"token","type":"address"},{"indexed":true,"internalType":"address","name":"feeTo","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"LogFeesCollected","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"maker","type":"address"},{"indexed":true,"internalType":"bytes32","name":"digest","type":"bytes32"},{"indexed":false,"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"},{"indexed":false,"internalType":"uint256","name":"fillAmount","type":"uint256"}],"name":"LogFillOrder","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"bytes32","name":"digest","type":"bytes32"}],"name":"LogOrderCancelled","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"feeTo","type":"address"},{"indexed":false,"internalType":"uint256","name":"externalOrderFee","type":"uint256"}],"name":"LogSetFees","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"}],"name":"LogWhiteListReceiver","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"inputs":[],"name":"FEE_DIVISOR","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes[]","name":"calls","type":"bytes[]"},{"internalType":"bool","name":"revertOnFail","type":"bool"}],"name":"batch","outputs":[{"internalType":"bool[]","name":"successes","type":"bool[]"},{"internalType":"bytes[]","name":"results","type":"bytes[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"maker","type":"address"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"startTime","type":"uint256"},{"internalType":"uint256","name":"endTime","type":"uint256"},{"internalType":"uint256","name":"stopPrice","type":"uint256"},{"internalType":"contract IOracle","name":"oracleAddress","type":"address"},{"internalType":"bytes","name":"oracleData","type":"bytes"},{"internalType":"uint256","name":"amountToFill","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"internalType":"struct StopLimitOrder.OrderArgs[]","name":"order","type":"tuple[]"},{"internalType":"contract IERC20","name":"tokenIn","type":"address"},{"internalType":"contract IERC20","name":"tokenOut","type":"address"},{"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"batchFillOrder","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"maker","type":"address"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"startTime","type":"uint256"},{"internalType":"uint256","name":"endTime","type":"uint256"},{"internalType":"uint256","name":"stopPrice","type":"uint256"},{"internalType":"contract IOracle","name":"oracleAddress","type":"address"},{"internalType":"bytes","name":"oracleData","type":"bytes"},{"internalType":"uint256","name":"amountToFill","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"internalType":"struct StopLimitOrder.OrderArgs[]","name":"order","type":"tuple[]"},{"internalType":"contract IERC20","name":"tokenIn","type":"address"},{"internalType":"contract IERC20","name":"tokenOut","type":"address"},{"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"batchFillOrderOpen","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"hash","type":"bytes32"}],"name":"cancelOrder","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"bytes32","name":"","type":"bytes32"}],"name":"cancelledOrder","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"claimOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"deploymentChainId","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"externalOrderFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feeTo","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"name":"feesCollected","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"maker","type":"address"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"startTime","type":"uint256"},{"internalType":"uint256","name":"endTime","type":"uint256"},{"internalType":"uint256","name":"stopPrice","type":"uint256"},{"internalType":"contract IOracle","name":"oracleAddress","type":"address"},{"internalType":"bytes","name":"oracleData","type":"bytes"},{"internalType":"uint256","name":"amountToFill","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"internalType":"struct StopLimitOrder.OrderArgs","name":"order","type":"tuple"},{"internalType":"contract IERC20","name":"tokenIn","type":"address"},{"internalType":"contract IERC20","name":"tokenOut","type":"address"},{"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"fillOrder","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"maker","type":"address"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"startTime","type":"uint256"},{"internalType":"uint256","name":"endTime","type":"uint256"},{"internalType":"uint256","name":"stopPrice","type":"uint256"},{"internalType":"contract IOracle","name":"oracleAddress","type":"address"},{"internalType":"bytes","name":"oracleData","type":"bytes"},{"internalType":"uint256","name":"amountToFill","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"internalType":"struct StopLimitOrder.OrderArgs","name":"order","type":"tuple"},{"internalType":"contract IERC20","name":"tokenIn","type":"address"},{"internalType":"contract IERC20","name":"tokenOut","type":"address"},{"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"fillOrderOpen","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"name":"orderStatus","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pendingOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permitToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_feeTo","type":"address"},{"internalType":"uint256","name":"_externalOrderFee","type":"uint256"}],"name":"setFees","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"}],"name":"swipe","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"}],"name":"swipeFees","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"},{"internalType":"bool","name":"direct","type":"bool"},{"internalType":"bool","name":"renounce","type":"bool"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract ILimitOrderReceiver","name":"receiver","type":"address"}],"name":"whiteListReceiver","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/limit-order-helper.json
const limit_order_helper_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IBentoBox","name":"_bentoBox","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"bentoBox","outputs":[{"internalType":"contract IBentoBox","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"},{"internalType":"address","name":"masterContract","type":"address"},{"internalType":"bool","name":"approved","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"depositAndApprove","outputs":[],"stateMutability":"payable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/maker.json
const maker_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/masterchef.json
const masterchef_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IERC20","name":"_rewardToken","type":"address"},{"internalType":"address","name":"_devaddr","type":"address"},{"internalType":"address","name":"_feeaddr","type":"address"},{"internalType":"uint256","name":"_rewardPerBlock","type":"uint256"},{"internalType":"uint256","name":"_startBlock","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"EmergencyWithdraw","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"caller","type":"address"},{"indexed":false,"internalType":"uint256","name":"previousAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"newAmount","type":"uint256"}],"name":"EmissionRateUpdated","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"rewardPerBlock","type":"uint256"}],"name":"NewRewardPerBlock","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Withdraw","type":"event"},{"inputs":[],"name":"BONUS_MULTIPLIER","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_allocPoint","type":"uint256"},{"internalType":"contract IERC20","name":"_lpToken","type":"address"},{"internalType":"bool","name":"_withUpdate","type":"bool"}],"name":"add","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_feeaddr","type":"address"}],"name":"commuity","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"commuityFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"deposit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_devaddr","type":"address"}],"name":"dev","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"devaddr","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"emergencyRewardWithdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"emergencyWithdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"feeaddr","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_from","type":"uint256"},{"internalType":"uint256","name":"_to","type":"uint256"}],"name":"getMultiplier","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"massUpdatePools","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"migrate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"migrator","outputs":[{"internalType":"contract IMigratorChef","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"address","name":"_user","type":"address"}],"name":"pendingReward","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"poolInfo","outputs":[{"internalType":"contract IERC20","name":"lpToken","type":"address"},{"internalType":"uint256","name":"allocPoint","type":"uint256"},{"internalType":"uint256","name":"lastRewardBlock","type":"uint256"},{"internalType":"uint256","name":"accRewardPerShare","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"poolLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_tokenAddress","type":"address"},{"internalType":"uint256","name":"_tokenAmount","type":"uint256"}],"name":"recoverWrongTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"rewardPerBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"rewardToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_allocPoint","type":"uint256"},{"internalType":"bool","name":"_withUpdate","type":"bool"}],"name":"set","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IMigratorChef","name":"_migrator","type":"address"}],"name":"setMigrator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"startBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalAllocPoint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_commuityFee","type":"uint256"}],"name":"updateEmissionRate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"updatePool","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_rewardPerBlock","type":"uint256"}],"name":"updateRewardPerBlock","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"userInfo","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"rewardDebt","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/masterchef-v2.json
const masterchef_v2_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IMasterChef","name":"_MASTER_CHEF","type":"address"},{"internalType":"contract IERC20","name":"_sushi","type":"address"},{"internalType":"uint256","name":"_MASTER_PID","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"EmergencyWithdraw","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Harvest","type":"event"},{"anonymous":false,"inputs":[],"name":"LogInit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"allocPoint","type":"uint256"},{"indexed":true,"internalType":"contract IERC20","name":"lpToken","type":"address"},{"indexed":true,"internalType":"contract IRewarder","name":"rewarder","type":"address"}],"name":"LogPoolAddition","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"allocPoint","type":"uint256"},{"indexed":true,"internalType":"contract IRewarder","name":"rewarder","type":"address"},{"indexed":false,"internalType":"bool","name":"overwrite","type":"bool"}],"name":"LogSetPool","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint64","name":"lastRewardBlock","type":"uint64"},{"indexed":false,"internalType":"uint256","name":"lpSupply","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"accSushiPerShare","type":"uint256"}],"name":"LogUpdatePool","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Withdraw","type":"event"},{"inputs":[],"name":"MASTER_CHEF","outputs":[{"internalType":"contract IMasterChef","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MASTER_PID","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SUSHI","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"allocPoint","type":"uint256"},{"internalType":"contract IERC20","name":"_lpToken","type":"address"},{"internalType":"contract IRewarder","name":"_rewarder","type":"address"}],"name":"add","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes[]","name":"calls","type":"bytes[]"},{"internalType":"bool","name":"revertOnFail","type":"bool"}],"name":"batch","outputs":[{"internalType":"bool[]","name":"successes","type":"bool[]"},{"internalType":"bytes[]","name":"results","type":"bytes[]"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"claimOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"deposit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"emergencyWithdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"harvest","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"harvestFromMasterChef","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"dummyToken","type":"address"}],"name":"init","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"lpToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"pids","type":"uint256[]"}],"name":"massUpdatePools","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"migrate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"migrator","outputs":[{"internalType":"contract IMigratorChef","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pendingOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"address","name":"_user","type":"address"}],"name":"pendingSushi","outputs":[{"internalType":"uint256","name":"pending","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permitToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"poolInfo","outputs":[{"internalType":"uint128","name":"accSushiPerShare","type":"uint128"},{"internalType":"uint64","name":"lastRewardBlock","type":"uint64"},{"internalType":"uint64","name":"allocPoint","type":"uint64"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"poolLength","outputs":[{"internalType":"uint256","name":"pools","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"rewarder","outputs":[{"internalType":"contract IRewarder","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_allocPoint","type":"uint256"},{"internalType":"contract IRewarder","name":"_rewarder","type":"address"},{"internalType":"bool","name":"overwrite","type":"bool"}],"name":"set","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IMigratorChef","name":"_migrator","type":"address"}],"name":"setMigrator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"sushiPerBlock","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalAllocPoint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"},{"internalType":"bool","name":"direct","type":"bool"},{"internalType":"bool","name":"renounce","type":"bool"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"}],"name":"updatePool","outputs":[{"components":[{"internalType":"uint128","name":"accSushiPerShare","type":"uint128"},{"internalType":"uint64","name":"lastRewardBlock","type":"uint64"},{"internalType":"uint64","name":"allocPoint","type":"uint64"}],"internalType":"struct MasterChefV2.PoolInfo","name":"pool","type":"tuple"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"userInfo","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"int256","name":"rewardDebt","type":"int256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"withdrawAndHarvest","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/meowshi.json
const meowshi_namespaceObject = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"delegator","type":"address"},{"indexed":true,"internalType":"address","name":"fromDelegate","type":"address"},{"indexed":true,"internalType":"address","name":"toDelegate","type":"address"}],"name":"DelegateChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"delegate","type":"address"},{"indexed":false,"internalType":"uint256","name":"previousBalance","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"newBalance","type":"uint256"}],"name":"DelegateVotesChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint32","name":"","type":"uint32"}],"name":"checkpoints","outputs":[{"internalType":"uint32","name":"fromBlock","type":"uint32"},{"internalType":"uint256","name":"votes","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"delegatee","type":"address"}],"name":"delegate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"delegatee","type":"address"},{"internalType":"uint256","name":"nonce","type":"uint256"},{"internalType":"uint256","name":"expiry","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"delegateBySig","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"delegates","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"getCurrentVotes","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"},{"internalType":"uint256","name":"blockNumber","type":"uint256"}],"name":"getPriorVotes","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"meow","outputs":[{"internalType":"uint256","name":"shares","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"meowSushi","outputs":[{"internalType":"uint256","name":"shares","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes[]","name":"data","type":"bytes[]"}],"name":"multicall","outputs":[{"internalType":"bytes[]","name":"results","type":"bytes[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"numCheckpoints","outputs":[{"internalType":"uint32","name":"","type":"uint32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"unmeow","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"unmeowSushi","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/merkle-distributor.json
const merkle_distributor_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/minichef-v2.json
const minichef_v2_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"contract IERC20","name":"_sushi","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"EmergencyWithdraw","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Harvest","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"allocPoint","type":"uint256"},{"indexed":true,"internalType":"contract IERC20","name":"lpToken","type":"address"},{"indexed":true,"internalType":"contract IRewarder","name":"rewarder","type":"address"}],"name":"LogPoolAddition","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"allocPoint","type":"uint256"},{"indexed":true,"internalType":"contract IRewarder","name":"rewarder","type":"address"},{"indexed":false,"internalType":"bool","name":"overwrite","type":"bool"}],"name":"LogSetPool","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"sushiPerSecond","type":"uint256"}],"name":"LogSushiPerSecond","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint64","name":"lastRewardTime","type":"uint64"},{"indexed":false,"internalType":"uint256","name":"lpSupply","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"accSushiPerShare","type":"uint256"}],"name":"LogUpdatePool","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":true,"internalType":"uint256","name":"pid","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Withdraw","type":"event"},{"inputs":[],"name":"SUSHI","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"allocPoint","type":"uint256"},{"internalType":"contract IERC20","name":"_lpToken","type":"address"},{"internalType":"contract IRewarder","name":"_rewarder","type":"address"}],"name":"add","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes[]","name":"calls","type":"bytes[]"},{"internalType":"bool","name":"revertOnFail","type":"bool"}],"name":"batch","outputs":[{"internalType":"bool[]","name":"successes","type":"bool[]"},{"internalType":"bytes[]","name":"results","type":"bytes[]"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"claimOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"deposit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"emergencyWithdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"harvest","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"lpToken","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"pids","type":"uint256[]"}],"name":"massUpdatePools","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"}],"name":"migrate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"migrator","outputs":[{"internalType":"contract IMigratorChef","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pendingOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"address","name":"_user","type":"address"}],"name":"pendingSushi","outputs":[{"internalType":"uint256","name":"pending","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC20","name":"token","type":"address"},{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permitToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"poolInfo","outputs":[{"internalType":"uint128","name":"accSushiPerShare","type":"uint128"},{"internalType":"uint64","name":"lastRewardTime","type":"uint64"},{"internalType":"uint64","name":"allocPoint","type":"uint64"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"poolLength","outputs":[{"internalType":"uint256","name":"pools","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"rewarder","outputs":[{"internalType":"contract IRewarder","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_pid","type":"uint256"},{"internalType":"uint256","name":"_allocPoint","type":"uint256"},{"internalType":"contract IRewarder","name":"_rewarder","type":"address"},{"internalType":"bool","name":"overwrite","type":"bool"}],"name":"set","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"contract IMigratorChef","name":"_migrator","type":"address"}],"name":"setMigrator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_sushiPerSecond","type":"uint256"}],"name":"setSushiPerSecond","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"sushiPerSecond","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalAllocPoint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"},{"internalType":"bool","name":"direct","type":"bool"},{"internalType":"bool","name":"renounce","type":"bool"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"}],"name":"updatePool","outputs":[{"components":[{"internalType":"uint128","name":"accSushiPerShare","type":"uint128"},{"internalType":"uint64","name":"lastRewardTime","type":"uint64"},{"internalType":"uint64","name":"allocPoint","type":"uint64"}],"internalType":"struct MiniChefV2.PoolInfo","name":"pool","type":"tuple"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"userInfo","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"int256","name":"rewardDebt","type":"int256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"pid","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"to","type":"address"}],"name":"withdrawAndHarvest","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/multicall2.json
const multicall2_namespaceObject = JSON.parse('[{"inputs":[{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"aggregate","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"},{"internalType":"bytes[]","name":"returnData","type":"bytes[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"blockAndAggregate","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"},{"internalType":"bytes32","name":"blockHash","type":"bytes32"},{"components":[{"internalType":"bool","name":"success","type":"bool"},{"internalType":"bytes","name":"returnData","type":"bytes"}],"internalType":"struct Multicall2.Result[]","name":"returnData","type":"tuple[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"}],"name":"getBlockHash","outputs":[{"internalType":"bytes32","name":"blockHash","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getBlockNumber","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockCoinbase","outputs":[{"internalType":"address","name":"coinbase","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockDifficulty","outputs":[{"internalType":"uint256","name":"difficulty","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockGasLimit","outputs":[{"internalType":"uint256","name":"gaslimit","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockTimestamp","outputs":[{"internalType":"uint256","name":"timestamp","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"addr","type":"address"}],"name":"getEthBalance","outputs":[{"internalType":"uint256","name":"balance","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getLastBlockHash","outputs":[{"internalType":"bytes32","name":"blockHash","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bool","name":"requireSuccess","type":"bool"},{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"tryAggregate","outputs":[{"components":[{"internalType":"bool","name":"success","type":"bool"},{"internalType":"bytes","name":"returnData","type":"bytes"}],"internalType":"struct Multicall2.Result[]","name":"returnData","type":"tuple[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"requireSuccess","type":"bool"},{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"tryBlockAndAggregate","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"},{"internalType":"bytes32","name":"blockHash","type":"bytes32"},{"components":[{"internalType":"bool","name":"success","type":"bool"},{"internalType":"bytes","name":"returnData","type":"bytes"}],"internalType":"struct Multicall2.Result[]","name":"returnData","type":"tuple[]"}],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/router.json
const router_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"address","name":"_factory","type":"address"},{"internalType":"address","name":"_WETH","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"WETH","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"amountADesired","type":"uint256"},{"internalType":"uint256","name":"amountBDesired","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"addLiquidity","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"},{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amountTokenDesired","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"addLiquidityETH","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"},{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"reserveIn","type":"uint256"},{"internalType":"uint256","name":"reserveOut","type":"uint256"}],"name":"getAmountIn","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"reserveIn","type":"uint256"},{"internalType":"uint256","name":"reserveOut","type":"uint256"}],"name":"getAmountOut","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"}],"name":"getAmountsIn","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"}],"name":"getAmountsOut","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"reserveA","type":"uint256"},{"internalType":"uint256","name":"reserveB","type":"uint256"}],"name":"quote","outputs":[{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidity","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidityETH","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidityETHSupportingFeeOnTransferTokens","outputs":[{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityETHWithPermit","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityETHWithPermitSupportingFeeOnTransferTokens","outputs":[{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityWithPermit","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapETHForExactTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactETHForTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactETHForTokensSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForETH","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForETHSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForTokensSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMax","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapTokensForExactETH","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMax","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapTokensForExactTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]');
;// CONCATENATED MODULE: ./src/constants/abis/sushi.json
const sushi_namespaceObject = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"delegator","type":"address"},{"indexed":true,"internalType":"address","name":"fromDelegate","type":"address"},{"indexed":true,"internalType":"address","name":"toDelegate","type":"address"}],"name":"DelegateChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"delegate","type":"address"},{"indexed":false,"internalType":"uint256","name":"previousBalance","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"newBalance","type":"uint256"}],"name":"DelegateVotesChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"DELEGATION_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DOMAIN_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint32","name":"","type":"uint32"}],"name":"checkpoints","outputs":[{"internalType":"uint32","name":"fromBlock","type":"uint32"},{"internalType":"uint256","name":"votes","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"delegatee","type":"address"}],"name":"delegate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"delegatee","type":"address"},{"internalType":"uint256","name":"nonce","type":"uint256"},{"internalType":"uint256","name":"expiry","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"delegateBySig","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"delegator","type":"address"}],"name":"delegates","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"getCurrentVotes","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"},{"internalType":"uint256","name":"blockNumber","type":"uint256"}],"name":"getPriorVotes","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_to","type":"address"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"mint","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"numCheckpoints","outputs":[{"internalType":"uint32","name":"","type":"uint32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/constants/abis/timelock.json
const timelock_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/uniswap-v2-factory.json
const uniswap_v2_factory_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/weth.json
const weth_namespaceObject = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"guy","type":"address"},{"name":"wad","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"src","type":"address"},{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"wad","type":"uint256"}],"name":"withdraw","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"deposit","outputs":[],"payable":true,"stateMutability":"payable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"guy","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Withdrawal","type":"event"}]');
;// CONCATENATED MODULE: ./src/constants/abis/zenko.json
const zenko_namespaceObject = [];
// EXTERNAL MODULE: ./src/functions/contract.ts + 2 modules
var contract = __webpack_require__(1520);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var hooks_useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
;// CONCATENATED MODULE: ./src/hooks/useContract.ts




































const UNI_FACTORY_ADDRESS = '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f';
function useEIP2612Contract(tokenAddress) {
  return useContract(tokenAddress, eip_2612_namespaceObject, false);
} // returns null on errors

function useContract(address, ABI, withSignerIfPossible = true) {
  const {
    library,
    account
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return (0,external_react_.useMemo)(() => {
    if (!address || !ABI || !library) return null;

    try {
      return (0,contract/* getContract */.uN)(address, ABI, library, withSignerIfPossible && account ? account : undefined);
    } catch (error) {
      console.error('Failed to get contract', error);
      return null;
    }
  }, [address, ABI, library, withSignerIfPossible, account]);
}
function useTokenContract(tokenAddress, withSignerIfPossible) {
  return useContract(tokenAddress, erc20, withSignerIfPossible);
}
function useWETH9Contract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.WNATIVE_ADDRESS[chainId], weth_namespaceObject, withSignerIfPossible);
}
function useArgentWalletDetectorContract() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId === sdk_.ChainId.MAINNET ? ARGENT_WALLET_DETECTOR_MAINNET_ADDRESS : undefined, argent_wallet_detector_namespaceObject, false);
}
function useENSRegistrarContract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.ENS_REGISTRAR_ADDRESS[chainId], ens_registrar_namespaceObject, withSignerIfPossible);
}
function useENSResolverContract(address, withSignerIfPossible) {
  return useContract(address, ens_public_resolver_namespaceObject, withSignerIfPossible);
}
function useBytes32TokenContract(tokenAddress, withSignerIfPossible) {
  return useContract(tokenAddress, erc20_bytes32_namespaceObject, withSignerIfPossible);
}
function usePairContract(pairAddress, withSignerIfPossible) {
  return useContract(pairAddress, uniswap_v2_pair_namespaceObject, withSignerIfPossible);
}
function useMerkleDistributorContract() {
  const {
    chainId
  } = useActiveWeb3React();
  return useContract(chainId ? MERKLE_DISTRIBUTOR_ADDRESS[chainId] : undefined, MERKLE_DISTRIBUTOR_ABI, true);
}
function useBoringHelperContract() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.BORING_HELPER_ADDRESS[chainId], boring_helper_namespaceObject, false);
}
function useMulticall2Contract() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.MULTICALL2_ADDRESS[chainId], multicall2_namespaceObject, false);
}
function useSushiContract(withSignerIfPossible = true) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.SUSHI_ADDRESS[chainId], sushi_namespaceObject, withSignerIfPossible);
}
function useLICPContract(withSignerIfPossible = true) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && constants/* LICP_ADDRESS */.Jf, erc20, withSignerIfPossible);
}
function useMasterChefContract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.MASTERCHEF_ADDRESS[chainId], masterchef_namespaceObject, withSignerIfPossible);
}
function useMasterChefV2Contract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.MASTERCHEF_V2_ADDRESS[chainId], masterchef_v2_namespaceObject, withSignerIfPossible);
}
function useMiniChefContract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.MINICHEF_ADDRESS[chainId], minichef_v2_namespaceObject, withSignerIfPossible);
}
function useFactoryContract() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.FACTORY_ADDRESS[chainId], factory_namespaceObject, false);
}
function useRouterContract(useArcher = false, withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  const address = useArcher ? sdk_.ARCHER_ROUTER_ADDRESS[chainId] : sdk_.ROUTER_ADDRESS[chainId];
  const abi = useArcher ? archer_router : router_namespaceObject;
  return useContract(address, abi, withSignerIfPossible);
}
function useSushiBarContract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.BAR_ADDRESS[chainId], bar_namespaceObject, withSignerIfPossible);
}
function useMakerContract() {
  const {
    chainId
  } = useActiveWeb3React();
  return useContract(chainId && MAKER_ADDRESS[chainId], MAKER_ABI, false);
}
function useTimelockContract() {
  const {
    chainId
  } = useActiveWeb3React();
  return useContract(chainId && TIMELOCK_ADDRESS[chainId], TIMELOCK_ABI, false);
}
function useBentoBoxContract(withSignerIfPossible) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(chainId && sdk_.BENTOBOX_ADDRESS[chainId], bentobox_namespaceObject, withSignerIfPossible);
}
function useChainlinkOracle() {
  const {
    chainId
  } = useActiveWeb3React();
  return useContract(chainId && CHAINLINK_ORACLE_ADDRESS[chainId], CHAINLINK_ORACLE_ABI, false);
}
function useUniV2FactoryContract() {
  return useContract(UNI_FACTORY_ADDRESS, UNI_FACTORY_ABI, false);
}
function useComplexRewarderContract(address, withSignerIfPossible) {
  return useContract(address, complex_rewarder_namespaceObject, withSignerIfPossible);
}
function useCloneRewarderContract(address, withSignerIfPossibe) {
  return useContract(address, clone_rewarder_namespaceObject, withSignerIfPossibe);
}
function useMeowshiContract(withSignerIfPossible) {
  return useContract('0x650F44eD6F1FE0E1417cb4b3115d52494B4D9b6D', meowshi_namespaceObject, withSignerIfPossible);
}
function useLimitOrderContract(withSignerIfPossibe) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  return useContract(sdk_.STOP_LIMIT_ORDER_ADDRESS[chainId], limit_order_namespaceObject, withSignerIfPossibe);
}
function useLimitOrderHelperContract(withSignerIfPossible) {
  return useContract('0xe2f736B7d1f6071124CBb5FC23E93d141CD24E12', limit_order_helper_namespaceObject, withSignerIfPossible);
}
function useInariContract(withSignerIfPossible) {
  return useContract('0x195E8262AA81Ba560478EC6Ca4dA73745547073f', INARI_ABI, withSignerIfPossible);
}
function useZenkoContract(withSignerIfPossible) {
  return useContract('0xa8f676c49f91655ab3b7c3ea2b73bb3088b2bc1f', ZENKO_ABI, withSignerIfPossible);
}

/***/ }),

/***/ 434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lk": () => (/* binding */ ApplicationModal),
/* harmony export */   "fG": () => (/* binding */ updateBlockNumber),
/* harmony export */   "i3": () => (/* binding */ setOpenModal),
/* harmony export */   "i8": () => (/* binding */ addPopup),
/* harmony export */   "hC": () => (/* binding */ removePopup),
/* harmony export */   "ZD": () => (/* binding */ setKashiApprovalPending)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

let ApplicationModal;

(function (ApplicationModal) {
  ApplicationModal[ApplicationModal["WALLET"] = 0] = "WALLET";
  ApplicationModal[ApplicationModal["SETTINGS"] = 1] = "SETTINGS";
  ApplicationModal[ApplicationModal["SELF_CLAIM"] = 2] = "SELF_CLAIM";
  ApplicationModal[ApplicationModal["ADDRESS_CLAIM"] = 3] = "ADDRESS_CLAIM";
  ApplicationModal[ApplicationModal["CLAIM_POPUP"] = 4] = "CLAIM_POPUP";
  ApplicationModal[ApplicationModal["MENU"] = 5] = "MENU";
  ApplicationModal[ApplicationModal["DELEGATE"] = 6] = "DELEGATE";
  ApplicationModal[ApplicationModal["VOTE"] = 7] = "VOTE";
  ApplicationModal[ApplicationModal["LANGUAGE"] = 8] = "LANGUAGE";
  ApplicationModal[ApplicationModal["NETWORK"] = 9] = "NETWORK";
})(ApplicationModal || (ApplicationModal = {}));

const updateBlockNumber = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('application/updateBlockNumber');
const setOpenModal = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('application/setOpenModal');
const addPopup = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('application/addPopup');
const removePopup = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('application/removePopup');
const setKashiApprovalPending = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('application/setKashiApprovalPending');

/***/ }),

/***/ 4663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ov": () => (/* binding */ useBlockNumber),
/* harmony export */   "oL": () => (/* binding */ useModalOpen),
/* harmony export */   "mq": () => (/* binding */ useWalletModalToggle),
/* harmony export */   "o": () => (/* binding */ useNetworkModalToggle),
/* harmony export */   "nU": () => (/* binding */ useToggleSettingsMenu),
/* harmony export */   "i$": () => (/* binding */ useAddPopup),
/* harmony export */   "J3": () => (/* binding */ useRemovePopup),
/* harmony export */   "iT": () => (/* binding */ useActivePopups),
/* harmony export */   "Fw": () => (/* binding */ useKashiApprovalPending)
/* harmony export */ });
/* unused harmony exports useToggleModal, useOpenModal, useCloseModals, useShowClaimPopup, useToggleShowClaimPopup, useToggleSelfClaimModal, useToggleDelegateModal, useToggleVoteModal */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8269);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(434);




function useBlockNumber() {
  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .a)();
  return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(state => state.application.blockNumber[chainId !== null && chainId !== void 0 ? chainId : -1]);
}
function useModalOpen(modal) {
  const openModal = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(state => state.application.openModal);
  return openModal === modal;
}
function useToggleModal(modal) {
  const open = useModalOpen(modal);
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_3__/* .setOpenModal */ .i3)(open ? null : modal)), [dispatch, modal, open]);
}
function useOpenModal(modal) {
  const dispatch = useDispatch();
  return useCallback(() => dispatch(setOpenModal(modal)), [dispatch, modal]);
}
function useCloseModals() {
  const dispatch = useDispatch();
  return useCallback(() => dispatch(setOpenModal(null)), [dispatch]);
}
function useWalletModalToggle() {
  return useToggleModal(_actions__WEBPACK_IMPORTED_MODULE_3__/* .ApplicationModal.WALLET */ .Lk.WALLET);
}
function useNetworkModalToggle() {
  return useToggleModal(_actions__WEBPACK_IMPORTED_MODULE_3__/* .ApplicationModal.NETWORK */ .Lk.NETWORK);
}
function useToggleSettingsMenu() {
  return useToggleModal(_actions__WEBPACK_IMPORTED_MODULE_3__/* .ApplicationModal.SETTINGS */ .Lk.SETTINGS);
}
function useShowClaimPopup() {
  return useModalOpen(ApplicationModal.CLAIM_POPUP);
}
function useToggleShowClaimPopup() {
  return useToggleModal(ApplicationModal.CLAIM_POPUP);
}
function useToggleSelfClaimModal() {
  return useToggleModal(ApplicationModal.SELF_CLAIM);
}
function useToggleDelegateModal() {
  return useToggleModal(ApplicationModal.DELEGATE);
}
function useToggleVoteModal() {
  return useToggleModal(ApplicationModal.VOTE);
} // returns a function that allows adding a popup

function useAddPopup() {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((content, key) => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_3__/* .addPopup */ .i8)({
      content,
      key
    }));
  }, [dispatch]);
} // returns a function that allows removing a popup via its key

function useRemovePopup() {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(key => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_3__/* .removePopup */ .hC)({
      key
    }));
  }, [dispatch]);
} // get the list of active popups

function useActivePopups() {
  const list = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(state => state.application.popupList);
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => list.filter(item => item.show), [list]);
}
function useKashiApprovalPending() {
  return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(state => state.application.kashiApprovalPending);
}

/***/ }),

/***/ 9268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ useAppDispatch),
/* harmony export */   "C": () => (/* binding */ useAppSelector)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useAppDispatch = () => (0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)();
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;

/***/ }),

/***/ 780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "v0": () => (/* binding */ useActiveListUrls),
  "R0": () => (/* binding */ useAllLists),
  "z0": () => (/* binding */ useCombinedActiveList),
  "eu": () => (/* binding */ useInactiveListUrls),
  "EF": () => (/* binding */ useIsListActive),
  "Rx": () => (/* binding */ useUnsupportedTokenList)
});

// UNUSED EXPORTS: listToTokenMap

// EXTERNAL MODULE: ./node_modules/@sushiswap/default-token-list/build/sushiswap-default.tokenlist.json
var sushiswap_default_tokenlist = __webpack_require__(2681);
// EXTERNAL MODULE: ./src/config/token-lists.ts
var token_lists = __webpack_require__(5090);
;// CONCATENATED MODULE: ./src/constants/token-lists/sushiswap-v2-unsupported.tokenlist.json
const sushiswap_v2_unsupported_tokenlist_namespaceObject = JSON.parse('{"name":"SushiSwap V2 Unsupported List","timestamp":"2021-01-05T20:47:02.923Z","version":{"major":1,"minor":0,"patch":0},"tags":{},"logoURI":"ipfs://QmNa8mQkrNKp1WEEeGjFezDmDeodkWRevGFN8JCV7b4Xir","keywords":["uniswap","unsupported"],"tokens":[{"name":"Gold Tether","address":"0x4922a015c4407F87432B179bb209e125432E4a2A","symbol":"XAUt","decimals":6,"chainId":1,"logoURI":"https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0x4922a015c4407F87432B179bb209e125432E4a2A/logo.png"}]}');
// EXTERNAL MODULE: ./src/state/lists/wrappedTokenInfo.ts
var wrappedTokenInfo = __webpack_require__(2045);
// EXTERNAL MODULE: ./src/functions/list.ts
var list = __webpack_require__(7284);
// EXTERNAL MODULE: ./src/state/hooks.ts
var hooks = __webpack_require__(9268);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./src/state/lists/hooks.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const listCache = typeof WeakMap !== 'undefined' ? new WeakMap() : null;
function listToTokenMap(list) {
  const result = listCache === null || listCache === void 0 ? void 0 : listCache.get(list);
  if (result) return result;
  const map = list.tokens.reduce((tokenMap, tokenInfo) => {
    var _tokenMap$token$chain;

    const token = new wrappedTokenInfo/* WrappedTokenInfo */.D(tokenInfo, list);

    if (((_tokenMap$token$chain = tokenMap[token.chainId]) === null || _tokenMap$token$chain === void 0 ? void 0 : _tokenMap$token$chain[token.address]) !== undefined) {
      console.error(new Error(`Duplicate token! ${token.address}`));
      return tokenMap;
    }

    return _objectSpread(_objectSpread({}, tokenMap), {}, {
      [token.chainId]: _objectSpread(_objectSpread({}, tokenMap[token.chainId]), {}, {
        [token.address]: {
          token,
          list
        }
      })
    });
  }, {});
  listCache === null || listCache === void 0 ? void 0 : listCache.set(list, map);
  return map;
}
const TRANSFORMED_DEFAULT_TOKEN_LIST = listToTokenMap(sushiswap_default_tokenlist);
function useAllLists() {
  return (0,hooks/* useAppSelector */.C)(state => state.lists.byUrl);
}

function combineMaps(map1, map2) {
  return {
    1: _objectSpread(_objectSpread({}, map1[1]), map2[1]),
    // mainnet
    3: _objectSpread(_objectSpread({}, map1[3]), map2[3]),
    // ropsten
    4: _objectSpread(_objectSpread({}, map1[4]), map2[4]),
    // rinkeby
    5: _objectSpread(_objectSpread({}, map1[5]), map2[5]),
    // goerli
    42: _objectSpread(_objectSpread({}, map1[42]), map2[42]),
    // kovan
    250: _objectSpread(_objectSpread({}, map1[250]), map2[250]),
    // fantom
    4002: _objectSpread(_objectSpread({}, map1[4002]), map2[4002]),
    // fantom testnet
    137: _objectSpread(_objectSpread({}, map1[137]), map2[137]),
    // matic
    80001: _objectSpread(_objectSpread({}, map1[80001]), map2[80001]),
    // matic testnet
    100: _objectSpread(_objectSpread({}, map1[100]), map2[100]),
    // xdai
    56: _objectSpread(_objectSpread({}, map1[56]), map2[56]),
    // bsc
    97: _objectSpread(_objectSpread({}, map1[97]), map2[97]),
    // bsc testnet
    42161: _objectSpread(_objectSpread({}, map1[42161]), map2[42161]),
    // arbitrum
    79377087078960: _objectSpread(_objectSpread({}, map1[79377087078960]), map2[79377087078960]),
    // arbitrum testnet
    1287: _objectSpread(_objectSpread({}, map1[1287]), map2[1287]),
    // moonbase
    128: _objectSpread(_objectSpread({}, map1[128]), map2[128]),
    // heco
    256: _objectSpread(_objectSpread({}, map1[256]), map2[256]),
    // heco testnet
    43114: _objectSpread(_objectSpread({}, map1[43114]), map2[43114]),
    // avax mainnet
    43113: _objectSpread(_objectSpread({}, map1[43113]), map2[43113]),
    // avax testnet fuji
    1666600000: _objectSpread(_objectSpread({}, map1[1666600000]), map2[1666600000]),
    // harmony
    1666700000: _objectSpread(_objectSpread({}, map1[1666700000]), map2[1666700000]),
    // harmony testnet
    66: _objectSpread(_objectSpread({}, map1[66]), map2[66]),
    // okex
    65: _objectSpread(_objectSpread({}, map1[65]), map2[65]),
    // okex testnet
    42220: _objectSpread(_objectSpread({}, map1[42220]), map2[42220]),
    // celo
    11297108109: _objectSpread(_objectSpread({}, map1[11297108109]), map2[11297108109]),
    // palm
    11297108099: _objectSpread(_objectSpread({}, map1[11297108099]), map2[11297108099]),
    // palm testnet
    1285: _objectSpread(_objectSpread({}, map1[1285]), map2[1285]) // moonriver

  };
} // merge tokens contained within lists from urls


function useCombinedTokenMapFromUrls(urls) {
  const lists = useAllLists();
  return (0,external_react_.useMemo)(() => {
    if (!urls) return {};
    return urls.slice() // sort by priority so top priority goes last
    .sort(list/* sortByListPriority */.MX).reduce((allTokens, currentUrl) => {
      var _lists$currentUrl;

      const current = (_lists$currentUrl = lists[currentUrl]) === null || _lists$currentUrl === void 0 ? void 0 : _lists$currentUrl.current;
      if (!current) return allTokens;

      try {
        return combineMaps(allTokens, listToTokenMap(current));
      } catch (error) {
        console.error('Could not show token list due to error', error);
        return allTokens;
      }
    }, {});
  }, [lists, urls]);
} // filter out unsupported lists


function useActiveListUrls() {
  var _useAppSelector;

  return (_useAppSelector = (0,hooks/* useAppSelector */.C)(state => state.lists.activeListUrls)) === null || _useAppSelector === void 0 ? void 0 : _useAppSelector.filter(url => !token_lists/* UNSUPPORTED_LIST_URLS.includes */.US.includes(url));
}
function useInactiveListUrls() {
  const lists = useAllLists();
  const allActiveListUrls = useActiveListUrls();
  return Object.keys(lists).filter(url => !(allActiveListUrls !== null && allActiveListUrls !== void 0 && allActiveListUrls.includes(url)) && !token_lists/* UNSUPPORTED_LIST_URLS.includes */.US.includes(url));
} // get all the tokens from active lists, combine with local default tokens

function useCombinedActiveList() {
  const activeListUrls = useActiveListUrls();
  const activeTokens = useCombinedTokenMapFromUrls(activeListUrls);
  return combineMaps(activeTokens, TRANSFORMED_DEFAULT_TOKEN_LIST);
} // list of tokens not supported on interface, used to show warnings and prevent swaps and adds

function useUnsupportedTokenList() {
  // get hard coded unsupported tokens
  const localUnsupportedListMap = listToTokenMap(sushiswap_v2_unsupported_tokenlist_namespaceObject); // get any loaded unsupported tokens

  const loadedUnsupportedListMap = useCombinedTokenMapFromUrls(token_lists/* UNSUPPORTED_LIST_URLS */.US); // format into one token address map

  return (0,external_react_.useMemo)(() => combineMaps(localUnsupportedListMap, loadedUnsupportedListMap), [localUnsupportedListMap, loadedUnsupportedListMap]);
}
function useIsListActive(url) {
  const activeListUrls = useActiveListUrls();
  return Boolean(activeListUrls === null || activeListUrls === void 0 ? void 0 : activeListUrls.includes(url));
}

/***/ }),

/***/ 2045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ WrappedTokenInfo)
/* harmony export */ });
/* harmony import */ var _functions_validate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2556);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



/**
 * Token instances created from token info on a token list.
 */
class WrappedTokenInfo {
  constructor(tokenInfo, list) {
    _defineProperty(this, "isNative", false);

    _defineProperty(this, "isToken", true);

    _defineProperty(this, "list", void 0);

    _defineProperty(this, "tokenInfo", void 0);

    _defineProperty(this, "_checksummedAddress", null);

    _defineProperty(this, "_tags", null);

    this.tokenInfo = tokenInfo;
    this.list = list;
  }

  get address() {
    if (this._checksummedAddress) return this._checksummedAddress;
    const checksummedAddress = (0,_functions_validate__WEBPACK_IMPORTED_MODULE_0__/* .isAddress */ .UJ)(this.tokenInfo.address);
    if (!checksummedAddress) throw new Error(`Invalid token address: ${this.tokenInfo.address}`);
    return this._checksummedAddress = checksummedAddress;
  }

  get chainId() {
    return this.tokenInfo.chainId;
  }

  get decimals() {
    return this.tokenInfo.decimals;
  }

  get name() {
    return this.tokenInfo.name;
  }

  get symbol() {
    return this.tokenInfo.symbol;
  }

  get logoURI() {
    return this.tokenInfo.logoURI;
  }

  get tags() {
    if (this._tags !== null) return this._tags;
    if (!this.tokenInfo.tags) return this._tags = [];
    const listTags = this.list.tags;
    if (!listTags) return this._tags = [];
    return this._tags = this.tokenInfo.tags.map(tagId => {
      return _objectSpread(_objectSpread({}, listTags[tagId]), {}, {
        id: tagId
      });
    });
  }

  equals(other) {
    return other.chainId === this.chainId && other.isToken && other.address.toLowerCase() === this.address.toLowerCase();
  }

  sortsBefore(other) {
    if (this.equals(other)) throw new Error('Addresses should not be equal');
    return this.address.toLowerCase() < other.address.toLowerCase();
  }

  get wrapped() {
    return this;
  }

  serialize() {
    return this.address;
  }

}

/***/ }),

/***/ 8995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dd": () => (/* binding */ addMulticallListeners),
/* harmony export */   "$x": () => (/* binding */ removeMulticallListeners),
/* harmony export */   "nu": () => (/* binding */ fetchingMulticallResults),
/* harmony export */   "wC": () => (/* binding */ errorFetchingMulticallResults),
/* harmony export */   "zT": () => (/* binding */ updateMulticallResults)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const addMulticallListeners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/addMulticallListeners');
const removeMulticallListeners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/removeMulticallListeners');
const fetchingMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/fetchingMulticallResults');
const errorFetchingMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/errorFetchingMulticallResults');
const updateMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/updateMulticallResults');

/***/ }),

/***/ 879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DB": () => (/* binding */ NEVER_RELOAD),
/* harmony export */   "es": () => (/* binding */ useSingleContractMultipleData),
/* harmony export */   "_Y": () => (/* binding */ useMultipleContractSingleData),
/* harmony export */   "Wk": () => (/* binding */ useSingleCallResult)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7601);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8995);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9268);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1446);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8269);
/* harmony import */ var _application_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4663);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









function isMethodArg(x) {
  return _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.isBigNumber(x) || ['string', 'number'].indexOf(typeof x) !== -1;
}

function isValidMethodArgs(x) {
  return x === undefined || Array.isArray(x) && x.every(xi => isMethodArg(xi) || Array.isArray(xi) && xi.every(isMethodArg));
}

const INVALID_RESULT = {
  valid: false,
  blockNumber: undefined,
  data: undefined
}; // use this options object

const NEVER_RELOAD = {
  blocksPerFetch: Infinity
}; // the lowest level call for subscribing to contract data

function useCallsData(calls, {
  blocksPerFetch
} = {
  blocksPerFetch: 1
}) {
  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__/* .useActiveWeb3React */ .a)();
  const callResults = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)(state => state.multicall.callResults);
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
  const serializedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    var _calls$filter$map$sor, _calls$filter, _calls$filter$map;

    return JSON.stringify((_calls$filter$map$sor = calls === null || calls === void 0 ? void 0 : (_calls$filter = calls.filter(c => Boolean(c))) === null || _calls$filter === void 0 ? void 0 : (_calls$filter$map = _calls$filter.map(_utils__WEBPACK_IMPORTED_MODULE_6__/* .toCallKey */ .k)) === null || _calls$filter$map === void 0 ? void 0 : _calls$filter$map.sort()) !== null && _calls$filter$map$sor !== void 0 ? _calls$filter$map$sor : []);
  }, [calls]); // update listeners when there is an actual change that persists for at least 100ms

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const callKeys = JSON.parse(serializedCallKeys);
    if (!chainId || callKeys.length === 0) return undefined;
    const calls = callKeys.map(key => (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .parseCallKey */ .g)(key));
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_0__/* .addMulticallListeners */ .Dd)({
      chainId,
      calls,
      options: {
        blocksPerFetch
      }
    }));
    return () => {
      dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_0__/* .removeMulticallListeners */ .$x)({
        chainId,
        calls,
        options: {
          blocksPerFetch
        }
      }));
    };
  }, [chainId, dispatch, blocksPerFetch, serializedCallKeys]);
  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => calls.map(call => {
    var _callResults$chainId;

    if (!chainId || !call) return INVALID_RESULT;
    const result = (_callResults$chainId = callResults[chainId]) === null || _callResults$chainId === void 0 ? void 0 : _callResults$chainId[(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .toCallKey */ .k)(call)];
    let data;

    if (result !== null && result !== void 0 && result.data && (result === null || result === void 0 ? void 0 : result.data) !== '0x') {
      data = result.data;
    }

    return {
      valid: true,
      data,
      blockNumber: result === null || result === void 0 ? void 0 : result.blockNumber
    };
  }), [callResults, calls, chainId]);
}

const INVALID_CALL_STATE = {
  valid: false,
  result: undefined,
  loading: false,
  syncing: false,
  error: false
};
const LOADING_CALL_STATE = {
  valid: true,
  result: undefined,
  loading: true,
  syncing: true,
  error: false
};

function toCallState(callResult, contractInterface, fragment, latestBlockNumber) {
  if (!callResult) return INVALID_CALL_STATE;
  const {
    valid,
    data,
    blockNumber
  } = callResult;
  if (!valid) return INVALID_CALL_STATE;
  if (valid && !blockNumber) return LOADING_CALL_STATE;
  if (!contractInterface || !fragment || !latestBlockNumber) return LOADING_CALL_STATE;
  const success = data && data.length > 2;
  const syncing = (blockNumber !== null && blockNumber !== void 0 ? blockNumber : 0) < latestBlockNumber;
  let result = undefined;

  if (success && data) {
    try {
      result = contractInterface.decodeFunctionResult(fragment, data);
    } catch (error) {
      console.debug('Result data parsing failed', fragment, data);
      return {
        valid: true,
        loading: false,
        error: true,
        syncing,
        result
      };
    }
  }

  return {
    valid: true,
    loading: false,
    syncing,
    result: result,
    error: !success
  };
}

function useSingleContractMultipleData(contract, methodName, callInputs, options, gasRequired) {
  const fragment = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    var _contract$interface;

    return contract === null || contract === void 0 ? void 0 : (_contract$interface = contract.interface) === null || _contract$interface === void 0 ? void 0 : _contract$interface.getFunction(methodName);
  }, [contract, methodName]);
  const calls = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => contract && fragment && (callInputs === null || callInputs === void 0 ? void 0 : callInputs.length) > 0 && callInputs.every(inputs => isValidMethodArgs(inputs)) ? callInputs.map(inputs => {
    return _objectSpread({
      address: contract.address,
      callData: contract.interface.encodeFunctionData(fragment, inputs)
    }, gasRequired ? {
      gasRequired
    } : {});
  }) : [], [contract, fragment, callInputs, gasRequired]);
  const results = useCallsData(calls, options);
  const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useBlockNumber */ .Ov)();
  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    return results.map(result => toCallState(result, contract === null || contract === void 0 ? void 0 : contract.interface, fragment, latestBlockNumber));
  }, [fragment, contract, results, latestBlockNumber]);
}
function useMultipleContractSingleData(addresses, contractInterface, methodName, callInputs, options, gasRequired) {
  const fragment = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => contractInterface.getFunction(methodName), [contractInterface, methodName]);
  const callData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => fragment && isValidMethodArgs(callInputs) ? contractInterface.encodeFunctionData(fragment, callInputs) : undefined, [callInputs, contractInterface, fragment]);
  const calls = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => fragment && addresses && addresses.length > 0 && callData ? addresses.map(address => {
    return address && callData ? _objectSpread({
      address,
      callData
    }, gasRequired ? {
      gasRequired
    } : {}) : undefined;
  }) : [], [addresses, callData, fragment, gasRequired]);
  const results = useCallsData(calls, options);
  const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useBlockNumber */ .Ov)();
  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    return results.map(result => toCallState(result, contractInterface, fragment, latestBlockNumber));
  }, [fragment, results, contractInterface, latestBlockNumber]);
}
function useSingleCallResult(contract, methodName, inputs, options, gasRequired) {
  const fragment = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    var _contract$interface2;

    return contract === null || contract === void 0 ? void 0 : (_contract$interface2 = contract.interface) === null || _contract$interface2 === void 0 ? void 0 : _contract$interface2.getFunction(methodName);
  }, [contract, methodName]);
  const calls = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    return contract && fragment && isValidMethodArgs(inputs) ? [_objectSpread({
      address: contract.address,
      callData: contract.interface.encodeFunctionData(fragment, inputs)
    }, gasRequired ? {
      gasRequired
    } : {})] : [];
  }, [contract, fragment, inputs, gasRequired]);
  const result = useCallsData(calls, options)[0];
  const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useBlockNumber */ .Ov)();
  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
    return toCallState(result, contract === null || contract === void 0 ? void 0 : contract.interface, fragment, latestBlockNumber);
  }, [result, contract, fragment, latestBlockNumber]);
}

/***/ }),

/***/ 7601:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ toCallKey),
/* harmony export */   "g": () => (/* binding */ parseCallKey)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function toCallKey(call) {
  let key = `${call.address}-${call.callData}`;

  if (call.gasRequired) {
    if (!Number.isSafeInteger(call.gasRequired)) {
      throw new Error(`Invalid number: ${call.gasRequired}`);
    }

    key += `-${call.gasRequired}`;
  }

  return key;
}
function parseCallKey(callKey) {
  const pcs = callKey.split('-');

  if (![2, 3].includes(pcs.length)) {
    throw new Error(`Invalid call key: ${callKey}`);
  }

  return _objectSpread({
    address: pcs[0],
    callData: pcs[1]
  }, pcs[2] ? {
    gasRequired: Number.parseInt(pcs[2])
  } : {});
}

/***/ }),

/***/ 7219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dT": () => (/* binding */ addTransaction),
/* harmony export */   "fY": () => (/* binding */ clearAllTransactions),
/* harmony export */   "Aw": () => (/* binding */ finalizeTransaction),
/* harmony export */   "LN": () => (/* binding */ checkedTransaction)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const addTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/addTransaction');
const clearAllTransactions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/clearAllTransactions');
const finalizeTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/finalizeTransaction');
const checkedTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/checkedTransaction');

/***/ }),

/***/ 9123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h7": () => (/* binding */ useTransactionAdder),
/* harmony export */   "kf": () => (/* binding */ useAllTransactions),
/* harmony export */   "mH": () => (/* binding */ isTransactionRecent),
/* harmony export */   "wB": () => (/* binding */ useHasPendingApproval)
/* harmony export */ });
/* unused harmony exports useIsTransactionPending, useUserHasSubmittedClaim */
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9268);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7219);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8269);




// helper that can take a ethers library transaction response and add it to the list of transactions
function useTransactionAdder() {
  const {
    chainId,
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* .useActiveWeb3React */ .a)();
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .T)();
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((response, {
    summary,
    approval,
    claim,
    archer
  } = {}) => {
    if (!account) return;
    if (!chainId) return;
    const {
      hash
    } = response;

    if (!hash) {
      throw Error('No transaction hash found.');
    }

    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .addTransaction */ .dT)({
      hash,
      from: account,
      chainId,
      approval,
      summary,
      claim,
      archer
    }));
  }, [dispatch, chainId, account]);
} // returns all the transactions for the current chain

function useAllTransactions() {
  var _state$chainId;

  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* .useActiveWeb3React */ .a)();
  const state = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppSelector */ .C)(state => state.transactions);
  return chainId ? (_state$chainId = state[chainId]) !== null && _state$chainId !== void 0 ? _state$chainId : {} : {};
}
function useIsTransactionPending(transactionHash) {
  const transactions = useAllTransactions();
  if (!transactionHash || !transactions[transactionHash]) return false;
  return !transactions[transactionHash].receipt;
}
/**
 * Returns whether a transaction happened in the last day (86400 seconds * 1000 milliseconds / second)
 * @param tx to check for recency
 */

function isTransactionRecent(tx) {
  return new Date().getTime() - tx.addedTime < 86400000;
} // returns whether a token has a pending approval transaction

function useHasPendingApproval(tokenAddress, spender) {
  const allTransactions = useAllTransactions();
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => typeof tokenAddress === 'string' && typeof spender === 'string' && Object.keys(allTransactions).some(hash => {
    const tx = allTransactions[hash];
    if (!tx) return false;

    if (tx.receipt) {
      return false;
    } else {
      const approval = tx.approval;
      if (!approval) return false;
      return approval.spender === spender && approval.tokenAddress === tokenAddress && isTransactionRecent(tx);
    }
  }), [allTransactions, spender, tokenAddress]);
} // watch for submissions to claim
// return null if not done loading, return undefined if not found

function useUserHasSubmittedClaim(account) {
  const allTransactions = useAllTransactions(); // get the txn if it has been submitted

  const claimTxn = useMemo(() => {
    const txnIndex = Object.keys(allTransactions).find(hash => {
      const tx = allTransactions[hash];
      return tx.claim && tx.claim.recipient === account;
    });
    return txnIndex && allTransactions[txnIndex] ? allTransactions[txnIndex] : undefined;
  }, [account, allTransactions]);
  return {
    claimSubmitted: Boolean(claimTxn),
    claimTxn
  };
}

/***/ }),

/***/ 8887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_I": () => (/* binding */ updateMatchesDarkMode),
/* harmony export */   "vP": () => (/* binding */ updateUserDarkMode),
/* harmony export */   "zv": () => (/* binding */ updateUserExpertMode),
/* harmony export */   "fO": () => (/* binding */ updateUserSingleHopOnly),
/* harmony export */   "rQ": () => (/* binding */ updateUserSlippageTolerance),
/* harmony export */   "gw": () => (/* binding */ updateUserDeadline),
/* harmony export */   "eg": () => (/* binding */ addSerializedToken),
/* harmony export */   "zQ": () => (/* binding */ removeSerializedToken),
/* harmony export */   "f9": () => (/* binding */ addSerializedPair),
/* harmony export */   "cd": () => (/* binding */ removeSerializedPair),
/* harmony export */   "ZU": () => (/* binding */ toggleURLWarning),
/* harmony export */   "WZ": () => (/* binding */ updateUserArcherUseRelay),
/* harmony export */   "HI": () => (/* binding */ updateUserArcherGasPrice),
/* harmony export */   "Z_": () => (/* binding */ updateUserArcherETHTip),
/* harmony export */   "N1": () => (/* binding */ updateUserArcherGasEstimate),
/* harmony export */   "NL": () => (/* binding */ updateUserArcherTipManualOverride)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const updateMatchesDarkMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateMatchesDarkMode');
const updateUserDarkMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserDarkMode');
const updateUserExpertMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserExpertMode');
const updateUserSingleHopOnly = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserSingleHopOnly');
const updateUserSlippageTolerance = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserSlippageTolerance');
const updateUserDeadline = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserDeadline');
const addSerializedToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/addSerializedToken');
const removeSerializedToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/removeSerializedToken');
const addSerializedPair = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/addSerializedPair');
const removeSerializedPair = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/removeSerializedPair');
const toggleURLWarning = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('app/toggleURLWarning');
const updateUserArcherUseRelay = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserArcherUseRelay');
const updateUserArcherGasPrice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserArcherGasPrice');
const updateUserArcherETHTip = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserArcherETHTip');
const updateUserArcherGasEstimate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserArcherGasEstimate');
const updateUserArcherTipManualOverride = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserArcherTipManualOverride');

/***/ }),

/***/ 181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DG": () => (/* binding */ useExpertModeManager),
/* harmony export */   "RO": () => (/* binding */ useUserSingleHopOnly),
/* harmony export */   "Ow": () => (/* binding */ useSetUserSlippageTolerance),
/* harmony export */   "$2": () => (/* binding */ useUserSlippageTolerance),
/* harmony export */   "A6": () => (/* binding */ useUserTransactionTTL),
/* harmony export */   "_E": () => (/* binding */ useAddUserToken),
/* harmony export */   "QG": () => (/* binding */ useRemoveUserAddedToken),
/* harmony export */   "em": () => (/* binding */ useUserAddedTokens),
/* harmony export */   "uB": () => (/* binding */ usePairAdder),
/* harmony export */   "wm": () => (/* binding */ useURLWarningVisible),
/* harmony export */   "Ce": () => (/* binding */ toV2LiquidityToken),
/* harmony export */   "B3": () => (/* binding */ useTrackedTokenPairs),
/* harmony export */   "AC": () => (/* binding */ useUserArcherUseRelay),
/* harmony export */   "Yq": () => (/* binding */ useUserArcherGasPrice),
/* harmony export */   "bg": () => (/* binding */ useUserArcherETHTip),
/* harmony export */   "uK": () => (/* binding */ useUserArcherGasEstimate),
/* harmony export */   "j8": () => (/* binding */ useUserArcherTipManualOverride),
/* harmony export */   "eq": () => (/* binding */ useUserSlippageToleranceWithDefault)
/* harmony export */ });
/* unused harmony exports useIsDarkMode, useDarkModeManager, useIsExpertMode, useURLWarningToggle */
/* harmony import */ var _config_routing__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5857);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8887);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9268);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_ga__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9831);
/* harmony import */ var react_ga__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_ga__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash_flatMap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3960);
/* harmony import */ var lodash_flatMap__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_flatMap__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8269);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6269);











function serializeToken(token) {
  return {
    chainId: token.chainId,
    address: token.address,
    decimals: token.decimals,
    symbol: token.symbol,
    name: token.name
  };
}

function deserializeToken(serializedToken) {
  return new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(serializedToken.chainId, serializedToken.address, serializedToken.decimals, serializedToken.symbol, serializedToken.name);
}

function useIsDarkMode() {
  const {
    userDarkMode,
    matchesDarkMode
  } = useAppSelector(({
    user: {
      matchesDarkMode,
      userDarkMode
    }
  }) => ({
    userDarkMode,
    matchesDarkMode
  }), shallowEqual);
  return userDarkMode === null ? matchesDarkMode : userDarkMode;
}
function useDarkModeManager() {
  const dispatch = useAppDispatch();
  const darkMode = useIsDarkMode();
  const toggleSetDarkMode = useCallback(() => {
    dispatch(updateUserDarkMode({
      userDarkMode: !darkMode
    }));
  }, [darkMode, dispatch]);
  return [darkMode, toggleSetDarkMode];
}
function useIsExpertMode() {
  return (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .C)(state => state.user.userExpertMode);
}
function useExpertModeManager() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const expertMode = useIsExpertMode();
  const toggleSetExpertMode = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(() => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserExpertMode */ .zv)({
      userExpertMode: !expertMode
    }));
  }, [expertMode, dispatch]);
  return [expertMode, toggleSetExpertMode];
}
function useUserSingleHopOnly() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const singleHopOnly = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .C)(state => state.user.userSingleHopOnly);
  const setSingleHopOnly = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(newSingleHopOnly => {
    react_ga__WEBPACK_IMPORTED_MODULE_6___default().event({
      category: 'Routing',
      action: newSingleHopOnly ? 'enable single hop' : 'disable single hop'
    });
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserSingleHopOnly */ .fO)({
      userSingleHopOnly: newSingleHopOnly
    }));
  }, [dispatch]);
  return [singleHopOnly, setSingleHopOnly];
}
function useSetUserSlippageTolerance() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(userSlippageTolerance => {
    let value;

    try {
      value = userSlippageTolerance === 'auto' ? 'auto' : _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.toNumber(userSlippageTolerance.multiply(10000).quotient);
    } catch (error) {
      value = 'auto';
    }

    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserSlippageTolerance */ .rQ)({
      userSlippageTolerance: value
    }));
  }, [dispatch]);
}
/**
 * Return the user's slippage tolerance, from the redux store, and a function to update the slippage tolerance
 */

function useUserSlippageTolerance() {
  const userSlippageTolerance = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .C)(state => {
    return state.user.userSlippageTolerance;
  });
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => userSlippageTolerance === 'auto' ? 'auto' : new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(userSlippageTolerance, 10000), [userSlippageTolerance]);
}
function useUserTransactionTTL() {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
  const userDeadline = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(state => {
    return state.user.userDeadline;
  });
  const setUserDeadline = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(userDeadline => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserDeadline */ .gw)({
      userDeadline
    }));
  }, [dispatch]);
  return [userDeadline, setUserDeadline];
}
function useAddUserToken() {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(token => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .addSerializedToken */ .eg)({
      serializedToken: serializeToken(token)
    }));
  }, [dispatch]);
}
function useRemoveUserAddedToken() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)((chainId, address) => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .removeSerializedToken */ .zQ)({
      chainId,
      address
    }));
  }, [dispatch]);
}
function useUserAddedTokens() {
  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__/* .useActiveWeb3React */ .a)();
  const serializedTokensMap = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .C)(({
    user: {
      tokens
    }
  }) => tokens);
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => {
    var _serializedTokensMap$;

    if (!chainId) return [];
    return Object.values((_serializedTokensMap$ = serializedTokensMap === null || serializedTokensMap === void 0 ? void 0 : serializedTokensMap[chainId]) !== null && _serializedTokensMap$ !== void 0 ? _serializedTokensMap$ : {}).map(deserializeToken);
  }, [serializedTokensMap, chainId]);
}

function serializePair(pair) {
  return {
    token0: serializeToken(pair.token0),
    token1: serializeToken(pair.token1)
  };
}

function usePairAdder() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(pair => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .addSerializedPair */ .f9)({
      serializedPair: serializePair(pair)
    }));
  }, [dispatch]);
}
function useURLWarningVisible() {
  return (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .C)(state => state.user.URLWarningVisible);
}
function useURLWarningToggle() {
  const dispatch = useAppDispatch();
  return useCallback(() => dispatch(toggleURLWarning()), [dispatch]);
}
/**
 * Given two tokens return the liquidity token that represents its liquidity shares
 * @param tokenA one of the two tokens
 * @param tokenB the other token
 */

function toV2LiquidityToken([tokenA, tokenB]) {
  if (tokenA.chainId !== tokenB.chainId) throw new Error('Not matching chain IDs');
  if (tokenA.equals(tokenB)) throw new Error('Tokens cannot be equal');
  if (!_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.FACTORY_ADDRESS[tokenA.chainId]) throw new Error('No V2 factory address on this chain');
  return new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(tokenA.chainId, (0,_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.computePairAddress)({
    factoryAddress: _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.FACTORY_ADDRESS[tokenA.chainId],
    tokenA,
    tokenB
  }), 18, 'UNI-V2', 'Uniswap V2');
}
/**
 * Returns all the pairs of tokens that are tracked by the user for the current chain ID.
 */

function useTrackedTokenPairs() {
  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__/* .useActiveWeb3React */ .a)();
  const tokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_9__/* .useAllTokens */ .e_)(); // pinned pairs

  const pinnedPairs = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => {
    var _PINNED_PAIRS$chainId;

    return chainId ? (_PINNED_PAIRS$chainId = _config_routing__WEBPACK_IMPORTED_MODULE_0__/* .PINNED_PAIRS */ .Q8[chainId]) !== null && _PINNED_PAIRS$chainId !== void 0 ? _PINNED_PAIRS$chainId : [] : [];
  }, [chainId]); // pairs for every token against every base

  const generatedPairs = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => chainId ? lodash_flatMap__WEBPACK_IMPORTED_MODULE_7___default()(Object.keys(tokens), tokenAddress => {
    var _BASES_TO_TRACK_LIQUI;

    const token = tokens[tokenAddress]; // for each token on the current chain,

    return (// loop though all bases on the current chain
      ((_BASES_TO_TRACK_LIQUI = _config_routing__WEBPACK_IMPORTED_MODULE_0__/* .BASES_TO_TRACK_LIQUIDITY_FOR */ .xu[chainId]) !== null && _BASES_TO_TRACK_LIQUI !== void 0 ? _BASES_TO_TRACK_LIQUI : []).map(base => {
        if (base.address === token.address) {
          return null;
        } else {
          return [base, token];
        }
      }).filter(p => p !== null)
    );
  }) : [], [tokens, chainId]); // pairs saved by users

  const savedSerializedPairs = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .C)(({
    user: {
      pairs
    }
  }) => pairs);
  const userPairs = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => {
    if (!chainId || !savedSerializedPairs) return [];
    const forChain = savedSerializedPairs[chainId];
    if (!forChain) return [];
    return Object.keys(forChain).map(pairId => {
      return [deserializeToken(forChain[pairId].token0), deserializeToken(forChain[pairId].token1)];
    });
  }, [savedSerializedPairs, chainId]);
  const combinedList = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => userPairs.concat(generatedPairs).concat(pinnedPairs), [generatedPairs, pinnedPairs, userPairs]);
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => {
    // dedupes pairs of tokens in the combined list
    const keyed = combinedList.reduce((memo, [tokenA, tokenB]) => {
      const sorted = tokenA.sortsBefore(tokenB);
      const key = sorted ? `${tokenA.address}:${tokenB.address}` : `${tokenB.address}:${tokenA.address}`;
      if (memo[key]) return memo;
      memo[key] = sorted ? [tokenA, tokenB] : [tokenB, tokenA];
      return memo;
    }, {});
    return Object.keys(keyed).map(key => keyed[key]);
  }, [combinedList]);
}
function useUserArcherUseRelay() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const useRelay = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(state => state.user.userArcherUseRelay);
  const setUseRelay = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(newUseRelay => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserArcherUseRelay */ .WZ)({
      userArcherUseRelay: newUseRelay
    }));
  }, [dispatch]);
  return [useRelay, setUseRelay];
}
function useUserArcherGasPrice() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const userGasPrice = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(state => {
    return state.user.userArcherGasPrice;
  });
  const setUserGasPrice = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(newGasPrice => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserArcherGasPrice */ .HI)({
      userArcherGasPrice: newGasPrice
    }));
  }, [dispatch]);
  return [userGasPrice, setUserGasPrice];
}
function useUserArcherETHTip() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const userETHTip = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(state => {
    return state.user.userArcherETHTip;
  });
  const setUserETHTip = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(newETHTip => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserArcherETHTip */ .Z_)({
      userArcherETHTip: newETHTip
    }));
  }, [dispatch]);
  return [userETHTip, setUserETHTip];
}
function useUserArcherGasEstimate() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const userGasEstimate = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(state => {
    return state.user.userArcherGasEstimate;
  });
  const setUserGasEstimate = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(newGasEstimate => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserArcherGasEstimate */ .N1)({
      userArcherGasEstimate: newGasEstimate
    }));
  }, [dispatch]);
  return [userGasEstimate, setUserGasEstimate];
}
function useUserArcherTipManualOverride() {
  const dispatch = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .T)();
  const userTipManualOverride = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(state => {
    return state.user.userArcherTipManualOverride;
  });
  const setUserTipManualOverride = (0,react__WEBPACK_IMPORTED_MODULE_5__.useCallback)(newManualOverride => {
    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_2__/* .updateUserArcherTipManualOverride */ .NL)({
      userArcherTipManualOverride: newManualOverride
    }));
  }, [dispatch]);
  return [userTipManualOverride, setUserTipManualOverride];
}
/**
 * Same as above but replaces the auto with a default value
 * @param defaultSlippageTolerance the default value to replace auto with
 */

function useUserSlippageToleranceWithDefault(defaultSlippageTolerance) {
  const allowedSlippage = useUserSlippageTolerance();
  return (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(() => allowedSlippage === 'auto' ? defaultSlippageTolerance : allowedSlippage, [allowedSlippage, defaultSlippageTolerance]);
}

/***/ }),

/***/ 2319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AE": () => (/* binding */ useETHBalances),
/* harmony export */   "v2": () => (/* binding */ useTokenBalancesWithLoadingIndicator),
/* harmony export */   "Z": () => (/* binding */ useTokenBalances),
/* harmony export */   "mM": () => (/* binding */ useTokenBalance),
/* harmony export */   "K5": () => (/* binding */ useCurrencyBalances),
/* harmony export */   "_h": () => (/* binding */ useCurrencyBalance),
/* harmony export */   "uD": () => (/* binding */ useAllTokenBalances)
/* harmony export */ });
/* unused harmony export serializeBalancesMap */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _multicall_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(879);
/* harmony import */ var _constants_abis_erc20_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9638);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6124);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _functions_validate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2556);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8269);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6269);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6435);










/**
 * Returns a map of the given addresses to their eventually consistent ETH balances.
 */
function useETHBalances(uncheckedAddresses) {
  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .a)();
  const multicallContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_8__/* .useMulticall2Contract */ .Fe)();
  const addresses = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => uncheckedAddresses ? uncheckedAddresses.map(_functions_validate__WEBPACK_IMPORTED_MODULE_4__/* .isAddress */ .UJ).filter(a => a !== false).sort() : [], [uncheckedAddresses]);
  const results = (0,_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleContractMultipleData */ .es)(multicallContract, 'getEthBalance', addresses.map(address => [address]));
  return (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => addresses.reduce((memo, address, i) => {
    var _results$i, _results$i$result;

    const value = results === null || results === void 0 ? void 0 : (_results$i = results[i]) === null || _results$i === void 0 ? void 0 : (_results$i$result = _results$i.result) === null || _results$i$result === void 0 ? void 0 : _results$i$result[0];
    if (value && chainId) memo[address] = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.NATIVE[chainId], _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(value.toString()));
    return memo;
  }, {}), [addresses, chainId, results]);
}
/**
 * Returns a map of token addresses to their eventually consistent token balances for a single account.
 */

function useTokenBalancesWithLoadingIndicator(address, tokens) {
  const validatedTokens = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => {
    var _tokens$filter;

    return (_tokens$filter = tokens === null || tokens === void 0 ? void 0 : tokens.filter(t => (0,_functions_validate__WEBPACK_IMPORTED_MODULE_4__/* .isAddress */ .UJ)(t === null || t === void 0 ? void 0 : t.address) !== false)) !== null && _tokens$filter !== void 0 ? _tokens$filter : [];
  }, [tokens]);
  const validatedTokenAddresses = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => validatedTokens.map(vt => vt.address), [validatedTokens]);
  const ERC20Interface = new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__.Interface(_constants_abis_erc20_json__WEBPACK_IMPORTED_MODULE_2__);
  const balances = (0,_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useMultipleContractSingleData */ ._Y)(validatedTokenAddresses, ERC20Interface, 'balanceOf', [address], undefined, 100000);
  const anyLoading = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => balances.some(callState => callState.loading), [balances]);
  return [(0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => address && validatedTokens.length > 0 ? validatedTokens.reduce((memo, token, i) => {
    var _balances$i, _balances$i$result;

    const value = balances === null || balances === void 0 ? void 0 : (_balances$i = balances[i]) === null || _balances$i === void 0 ? void 0 : (_balances$i$result = _balances$i.result) === null || _balances$i$result === void 0 ? void 0 : _balances$i$result[0];
    const amount = value ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(value.toString()) : undefined;

    if (amount) {
      memo[token.address] = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(token, amount);
    }

    return memo;
  }, {}) : {}, [address, validatedTokens, balances]), anyLoading];
}
const serializeBalancesMap = mapping => {
  return Object.entries(mapping).map(([address, currencyAmount]) => currencyAmount.serialize()).join();
};
function useTokenBalances(address, tokens) {
  const balances = useTokenBalancesWithLoadingIndicator(address, tokens)[0];
  const memoizedBalances = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => serializeBalancesMap(balances), [balances]);
  return (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => balances, [memoizedBalances]);
} // get the balance for a single token/account combo

function useTokenBalance(account, token) {
  const tokenBalances = useTokenBalances(account, [token]);
  if (!token) return undefined;
  return tokenBalances[token.address];
}
function useCurrencyBalances(account, currencies) {
  const tokens = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => {
    var _currencies$filter;

    return (_currencies$filter = currencies === null || currencies === void 0 ? void 0 : currencies.filter(currency => {
      var _currency$isToken;

      return (_currency$isToken = currency === null || currency === void 0 ? void 0 : currency.isToken) !== null && _currency$isToken !== void 0 ? _currency$isToken : false;
    })) !== null && _currencies$filter !== void 0 ? _currencies$filter : [];
  }, [currencies]);
  const tokenBalances = useTokenBalances(account, tokens);
  const containsETH = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => {
    var _currencies$some;

    return (_currencies$some = currencies === null || currencies === void 0 ? void 0 : currencies.some(currency => currency === null || currency === void 0 ? void 0 : currency.isNative)) !== null && _currencies$some !== void 0 ? _currencies$some : false;
  }, [currencies]);
  const ethBalance = useETHBalances(containsETH ? [account] : []);
  return (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => {
    var _currencies$map;

    return (_currencies$map = currencies === null || currencies === void 0 ? void 0 : currencies.map(currency => {
      if (!account || !currency) return undefined;
      if (currency.isToken) return tokenBalances[currency.address];
      if (currency.isNative) return ethBalance[account];
      return undefined;
    })) !== null && _currencies$map !== void 0 ? _currencies$map : [];
  }, [account, currencies, ethBalance, tokenBalances]);
}
function useCurrencyBalance(account, currency) {
  return useCurrencyBalances(account, [currency])[0];
} // mimics useAllBalances

function useAllTokenBalances() {
  const {
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .a)();
  const allTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useAllTokens */ .e_)();
  const allTokensArray = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(() => Object.values(allTokens !== null && allTokens !== void 0 ? allTokens : {}), [allTokens]);
  return useTokenBalances(account !== null && account !== void 0 ? account : undefined, allTokensArray);
} // TODO: Replace
// get the total owned, unclaimed, and unharvested UNI for account
// export function useAggregateUniBalance(): CurrencyAmount<Token> | undefined {
//   const { account, chainId } = useActiveWeb3React();
//   const uni = chainId ? UNI[chainId] : undefined;
//   const uniBalance: CurrencyAmount<Token> | undefined = useTokenBalance(
//     account ?? undefined,
//     uni
//   );
//   const uniUnclaimed: CurrencyAmount<Token> | undefined =
//     useUserUnclaimedAmount(account);
//   const uniUnHarvested: CurrencyAmount<Token> | undefined = useTotalUniEarned();
//   if (!uni) return undefined;
//   return CurrencyAmount.fromRawAmount(
//     uni,
//     JSBI.add(
//       JSBI.add(
//         uniBalance?.quotient ?? JSBI.BigInt(0),
//         uniUnclaimed?.quotient ?? JSBI.BigInt(0)
//       ),
//       uniUnHarvested?.quotient ?? JSBI.BigInt(0)
//     )
//   );
// }

/***/ }),

/***/ 9638:
/***/ ((module) => {

module.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]');

/***/ })

};
;
//# sourceMappingURL=126.js.map